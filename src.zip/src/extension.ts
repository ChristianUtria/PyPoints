/**
 * PyPoints Endpoints — extension.ts
 *
 * Funcionalidades incluidas:
 * - Webview Automático de Actualizaciones / Migraciones (releaseNotesManager)
 * - Endpoint TreeView (EndpointProvider)
 * - Summary TreeView (SummaryProvider)
 * - CodeLens sobre archivos Python (EndpointCodeLensProvider)
 * - Status bar con contador de endpoints
 * - Comandos: endpointCounter.*, pypoints.codeLens*, pypoints.copyStructureFromContext
 * - Auto-refresh en cambios de archivos .py
 * - Recomendación de ArchView (cruzada)
 */

import * as vscode from 'vscode';
import { EndpointProvider }         from './providers/Endpointprovider';
import { SummaryProvider }          from './providers/Summaryprovider';
import { registerCommands }         from './commands';
import { EndpointCodeLensProvider } from './providers/endpointCodeLensProvider';
import { registerCodeLensCommands } from './commands/codeLensCommands';
import { t }                        from './utils/i18n';
import { checkAndShowReleaseNotes } from './utils/releaseNotesManager';

// ─────────────────────────────────────────────────────────────
// ArchView recommendation
// ─────────────────────────────────────────────────────────────

const ARCHVIEW_ID  = 'christian-dev.archview';
const NOTIFIED_KEY = 'pypoints.archviewNotified';

async function recommendArchView(context: vscode.ExtensionContext): Promise<void> {
  if (context.workspaceState.get<boolean>(NOTIFIED_KEY, false)) { return; }
  if (vscode.extensions.getExtension(ARCHVIEW_ID)) { return; }

  await context.workspaceState.update(NOTIFIED_KEY, true);

  const msg    = t();
  const action = await vscode.window.showInformationMessage(msg.archviewTip, msg.installBtn, msg.notNow);
  if (action === msg.installBtn) {
    vscode.commands.executeCommand('workbench.extensions.installExtension', ARCHVIEW_ID);
  }
}

export function activate(context: vscode.ExtensionContext) {

  // ── Webview Panel de Novedades / Migración ─────────────────────────────────
  // Revisa la versión definida en el template y despliega el panel si es necesario.
  checkAndShowReleaseNotes(context);

  // ── Status bar ────────────────────────────────────────────────────────────

  const statusBar = vscode.window.createStatusBarItem(vscode.StatusBarAlignment.Left, 100);
  statusBar.text    = '$(symbol-method) Endpoints';
  statusBar.command = 'endpointCounter.refresh';
  statusBar.show();
  context.subscriptions.push(statusBar);

  // ── CodeLens ──────────────────────────────────────────────────────────────

  const codeLensProvider = new EndpointCodeLensProvider();
  context.subscriptions.push(
    vscode.languages.registerCodeLensProvider(
      { language: 'python', scheme: 'file' },
      codeLensProvider
    )
  );
  registerCodeLensCommands(context, codeLensProvider);
  context.subscriptions.push(
    vscode.workspace.onDidChangeConfiguration(e => {
      if (e.affectsConfiguration('pypointsEndpoints')) { codeLensProvider.refresh(); }
    })
  );

  // ── Endpoint TreeView ─────────────────────────────────────────────────────

  const endpointProvider = new EndpointProvider(statusBar);
  const treeView = vscode.window.createTreeView('endpointExplorer', {
    treeDataProvider: endpointProvider,
    showCollapseAll:  true,
  });
  context.subscriptions.push(treeView);

  // ── Summary TreeView ──────────────────────────────────────────────────────

  const summaryProvider = new SummaryProvider();
  const summaryView = vscode.window.createTreeView('endpointSummary', {
    treeDataProvider: summaryProvider,
  });
  context.subscriptions.push(summaryView);

  endpointProvider.setSummaryProvider(summaryProvider);
  context.subscriptions.push(
    endpointProvider.onDidChangeTreeData(() => {
      summaryProvider.updateEndpoints(endpointProvider.getAllEndpoints());
    })
  );

  registerCommands(context, endpointProvider);
  endpointProvider.refresh();

  // ── Auto-refresh en .py ───────────────────────────────────────────────────

  let debounceTimer: NodeJS.Timeout | undefined;
  let pyWatcher: vscode.FileSystemWatcher | undefined;

  const scheduleRefresh = () => {
    if (debounceTimer) { clearTimeout(debounceTimer); }
    debounceTimer = setTimeout(() => endpointProvider.refresh(), 800);
  };

  const startWatcher = () => {
    pyWatcher?.dispose();
    pyWatcher = vscode.workspace.createFileSystemWatcher('**/*.py');
    pyWatcher.onDidChange(scheduleRefresh);
    pyWatcher.onDidCreate(scheduleRefresh);
    pyWatcher.onDidDelete(scheduleRefresh);
  };

  startWatcher();

  context.subscriptions.push(
    vscode.workspace.onDidChangeWorkspaceFolders(() => {
      startWatcher();
      endpointProvider.refresh();
    })
  );

  context.subscriptions.push(
    vscode.window.onDidChangeWindowState(e => {
      if (e.focused) { scheduleRefresh(); }
    })
  );

  context.subscriptions.push({ dispose: () => pyWatcher?.dispose() });

  // ── ArchView recommendation on activation ─────────────────────────────────

  setTimeout(() => recommendArchView(context), 3000);
}

export function deactivate() {}