import * as vscode from 'vscode';
import { EndpointCodeLensProvider } from '../providers/endpointCodeLensProvider';
import { showEndpointPreviewPanel } from '../webview/Previewpanel';
import { detectServerConfig } from '../server/Serverdetector';
import { Endpoint } from '../types';

export function registerCodeLensCommands(
  context: vscode.ExtensionContext,
  provider: EndpointCodeLensProvider
): void {

  const getServerCfg = () =>
    vscode.workspace.workspaceFolders
      ? detectServerConfig(vscode.workspace.workspaceFolders)
      : undefined;

  // ── Run / Test → abre el mismo panel que ya usa PyPoints ─────────────────
  context.subscriptions.push(
    vscode.commands.registerCommand(
      'pypoints.codeLensRun',
      (endpoint: Endpoint) => {
        showEndpointPreviewPanel(endpoint, context, getServerCfg());
      }
    )
  );

  // ── Copiar solo la ruta ───────────────────────────────────────────────────
  context.subscriptions.push(
    vscode.commands.registerCommand(
      'pypoints.codeLensCopyRoute',
      async (route: string) => {
        await vscode.env.clipboard.writeText(route);
        vscode.window.showInformationMessage(`PyPoints: Ruta copiada → ${route}`);
      }
    )
  );

  // ── Copiar cURL completo ──────────────────────────────────────────────────
  context.subscriptions.push(
    vscode.commands.registerCommand(
      'pypoints.codeLensCopyCurl',
      async (method: string, route: string) => {
        const serverCfg = getServerCfg();
        const baseUrl = serverCfg?.baseUrl
          ?? vscode.workspace.getConfiguration('pypoints').get<string>('baseUrl')
          ?? 'http://localhost:5000';

        let curl = `curl -X ${method.toUpperCase()} "${baseUrl}${route}"`;
        if (['POST', 'PUT', 'PATCH'].includes(method.toUpperCase())) {
          curl += ` \\\n  -H "Content-Type: application/json" \\\n  -d '{}'`;
        }

        await vscode.env.clipboard.writeText(curl);
        vscode.window.showInformationMessage(`PyPoints: cURL copiado → ${method.toUpperCase()} ${route}`);
      }
    )
  );

  // ── Refresh manual ────────────────────────────────────────────────────────
  context.subscriptions.push(
    vscode.commands.registerCommand(
      'pypoints.refreshCodeLens',
      () => provider.refresh()
    )
  );
}