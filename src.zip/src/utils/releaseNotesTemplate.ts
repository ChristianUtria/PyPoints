export const notesContent = {
    version: '2.0.0', 
    title: 'Novedades de PyPoints y Lanzamiento de ArchView',
    
    // Aquí comunicamos las dos noticias claramente
    intro: 'Tenemos dos grandes noticias. Primero, <strong>el historial de endpoints en PyPoints ha sido mejorado y ahora es permanente</strong>. Segundo, la funcionalidad de estructura evolucionó a su propia extensión dedicada: <strong>ArchView – AI Context Builder & Project Structure Explorer</strong>. Una herramienta diseñada para mapear proyectos, comprimir tokens y construir contexto para IA (Claude, ChatGPT, Copilot) sin salir de VS Code.',
    
    featuresTitle: '¿Qué puedes hacer con la nueva extensión ArchView?',
    
    // Resumen de las features del README
    features: [
        '<strong>AI Context Builder:</strong> Selecciona archivos, analiza su peso en tokens y prepáralos para enviarlos a cualquier LLM.',
        '<strong>Token Optimization:</strong> Tres perfiles (Fast, Balanced, AI Max) para comprimir código, eliminar ruido y ahorrar tokens.',
        '<strong>Summarize with Claude:</strong> Integración nativa con la API de Anthropic para generar resúmenes automáticos de tu contexto.',
        '<strong>Live Project Structure:</strong> Visualiza y copia la estructura completa de tu proyecto para explicársela a la IA.',
        '<strong>Compatibilidad Universal:</strong> Soporte total para Node.js, Next.js, Python, PHP, Laravel, React y más.'
    ],

    // Nueva sección informando sobre el futuro de PyPoints
    pypointsFutureTitle: '¿Qué sigue para PyPoints?',
    pypointsFuture: 'Seguimos trabajando fuertemente en el core de PyPoints. Actualmente estamos agregando <strong>nuevas funcionalidades para la gestión y prueba de REST APIs</strong>, y en las próximas versiones ampliaremos el soporte para incluir muchos más lenguajes de programación.',
    
    outro: 'Instala ArchView y olvídate de la fricción al copiar y pegar archivos manualmente hacia tus modelos de IA.',
    buttonText: 'Descargar ArchView',
    
    footer: 'Gracias por utilizar PyPoints. Seguimos creando herramientas para potenciar tu desarrollo.'
};

export function getReleaseNotesHtml(imageUri: string): string {
    const featuresHtml = notesContent.features.map(f => `
        <li class="feature-item">
            <svg class="feature-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                <polyline points="20 6 9 17 4 12"></polyline>
            </svg>
            <span>${f}</span>
        </li>
    `).join('');

    return `
    <!DOCTYPE html>
    <html lang="es">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <style>
            :root {
                --border-color: var(--vscode-widget-border, #e4e4e4);
                --bg-secondary: var(--vscode-textCodeBlock-background, rgba(0, 0, 0, 0.04));
            }
            body {
                font-family: var(--vscode-font-family), -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Arial, sans-serif;
                padding: 40px 5%;
                color: var(--vscode-editor-foreground);
                background-color: var(--vscode-editor-background);
                line-height: 1.6;
                max-width: 100%;
                margin: 0 auto;
            }
            .container {
                padding-bottom: 20px;
            }
            h1 {
                font-size: 1.8rem;
                font-weight: 600;
                margin: 0 0 24px 0;
                color: var(--vscode-editor-foreground);
                letter-spacing: -0.3px;
            }
            .banner {
                width: 100%;
                max-height: 400px;
                object-fit: cover;
                border-radius: 6px;
                margin-bottom: 30px;
                border: 1px solid var(--border-color);
                display: block;
            }
            p {
                font-size: 1rem;
                color: var(--vscode-descriptionForeground);
                margin: 0 0 24px 0;
            }
            .info-box {
                background-color: var(--bg-secondary);
                border-left: 3px solid var(--vscode-button-background);
                padding: 20px;
                border-radius: 4px;
                margin-bottom: 32px;
            }
            /* Variante sutil para destacar la noticia de PyPoints sin quitar protagonismo a ArchView */
            .info-box.secondary {
                border-left-color: var(--vscode-editorInfo-foreground, #3794ff);
                margin-top: 10px;
            }
            .info-box p {
                margin: 0;
                color: var(--vscode-editor-foreground);
            }
            h2 {
                font-size: 1.2rem;
                font-weight: 600;
                margin: 0 0 16px 0;
                color: var(--vscode-editor-foreground);
            }
            ul {
                list-style: none;
                padding: 0;
                margin: 0 0 32px 0;
            }
            .feature-item {
                display: flex;
                align-items: flex-start;
                margin-bottom: 16px;
                font-size: 1rem;
                color: var(--vscode-editor-foreground);
            }
            .feature-icon {
                width: 20px;
                height: 20px;
                margin-right: 12px;
                margin-top: 3px;
                color: var(--vscode-button-background);
                flex-shrink: 0;
            }
            .btn {
                display: inline-block;
                text-align: center;
                background: var(--vscode-button-background);
                color: var(--vscode-button-foreground);
                border: 1px solid transparent;
                padding: 12px 24px;
                font-size: 1rem;
                font-weight: 500;
                border-radius: 4px;
                cursor: pointer;
                transition: background-color 0.2s;
                margin-top: 10px;
            }
            .btn:hover {
                background: var(--vscode-button-hoverBackground);
            }
            .footer {
                margin-top: 40px;
                padding-top: 24px;
                border-top: 1px solid var(--border-color);
                font-size: 0.9rem;
                color: var(--vscode-disabledForeground);
            }
        </style>
    </head>
    <body>
        <div class="container">
            <h1>${notesContent.title}</h1>
            
            <img src="${imageUri}" alt="ArchView Extension Banner" class="banner">
            
            <div class="info-box">
                <p>${notesContent.intro}</p>
            </div>
            
            <h2>${notesContent.featuresTitle}</h2>
            <ul>
                ${featuresHtml}
            </ul>

            <h2>${notesContent.pypointsFutureTitle}</h2>
            <div class="info-box secondary">
                <p>${notesContent.pypointsFuture}</p>
            </div>
            
            <p>${notesContent.outro}</p>
            
            <button id="install-btn" class="btn">${notesContent.buttonText}</button>
        </div>
        
        <div class="footer">
            ${notesContent.footer}
        </div>

        <script>
            const vscode = acquireVsCodeApi();
            
            document.getElementById('install-btn').addEventListener('click', () => {
                vscode.postMessage({ command: 'openExtension' });
            });
        </script>
    </body>
    </html>
    `;
}