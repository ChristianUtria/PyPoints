import * as vscode from 'vscode';
import { notesContent, getReleaseNotesHtml } from './releaseNotesTemplate';

const STATE_VERSION_KEY = 'pypoints.lastReleaseNotesVersion';

export function checkAndShowReleaseNotes(context: vscode.ExtensionContext) {
    const currentVersion = notesContent.version;
    const lastVersion = context.globalState.get<string>(STATE_VERSION_KEY);

    if (lastVersion !== currentVersion) {
    showReleaseNotesPanel(context);
    context.globalState.update(STATE_VERSION_KEY, currentVersion);
    }
}

function showReleaseNotesPanel(context: vscode.ExtensionContext) {
    const panel = vscode.window.createWebviewPanel(
        'pypointsReleaseNotes',
        'Novedades de PyPoints',
        vscode.ViewColumn.One,
        {
            enableScripts: true,
            retainContextWhenHidden: true,
            localResourceRoots: [vscode.Uri.joinPath(context.extensionUri, 'media')]
        }
    );

    const imagePath = vscode.Uri.joinPath(context.extensionUri, 'media', 'archview-banner.png');
    const imageUri = panel.webview.asWebviewUri(imagePath);

    panel.webview.html = getReleaseNotesHtml(imageUri.toString());

    panel.webview.onDidReceiveMessage(
        message => {
            if (message.command === 'openExtension') {
                vscode.commands.executeCommand('extension.open', 'christian-dev.archviews');
            }
        },
        undefined,
        context.subscriptions
    );
}