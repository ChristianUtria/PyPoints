import * as vscode from 'vscode';
import { Endpoint } from '../types';
import { EndpointItem } from './Endpointitem';
import { COMPLEXITY_ICON } from '../utils/complexity';

export class SummaryProvider implements vscode.TreeDataProvider<EndpointItem> {
  private _onDidChangeTreeData = new vscode.EventEmitter<void>();
  readonly onDidChangeTreeData = this._onDidChangeTreeData.event;

  private _endpoints: Endpoint[] = [];

  update(text: string) {
    // legacy compat — ignored, use updateEndpoints instead
    this._onDidChangeTreeData.fire();
  }

  updateEndpoints(endpoints: Endpoint[]) {
    this._endpoints = endpoints;
    this._onDidChangeTreeData.fire();
  }

  getTreeItem(el: EndpointItem) { return el; }

  getChildren(el?: EndpointItem): EndpointItem[] {
    if (el) return el.children ?? [];
    if (!this._endpoints.length) return [this._empty()];
    return this._buildTree();
  }

  // ── builders ────────────────────────────────────────────────────────────

  private _buildTree(): EndpointItem[] {
    const eps = this._endpoints;
    const items: EndpointItem[] = [];

    // ── 1. Overview ──────────────────────────────────────────────────────
    const total    = eps.length;
    const errors   = eps.filter(e => e.issues?.some(i => i.type === 'error')).length;
    const warnings = eps.filter(e => e.issues?.some(i => i.type === 'warning')).length;
    const dupes    = eps.filter(e => e.isDuplicate).length;
    const files    = new Set(eps.map(e => e.filePath)).size;
    const frameworks = [...new Set(eps.map(e => e.framework))].join(', ');

    const overviewChildren: EndpointItem[] = [
      this._stat('Total endpoints',      `${total}`,    'symbol-method',   'charts.blue'),
      this._stat('Archivos escaneados',  `${files}`,    'file-code',       'charts.purple'),
      this._stat('Frameworks',           frameworks||'—','layers',          'charts.orange'),
      this._stat('Errores',              `${errors}`,   'error',           errors   > 0 ? 'errorForeground'          : 'charts.green'),
      this._stat('Advertencias',         `${warnings}`, 'warning',         warnings > 0 ? 'editorWarning.foreground' : 'charts.green'),
      this._stat('Duplicados',           `${dupes}`,    'copy',            dupes    > 0 ? 'editorWarning.foreground' : 'charts.green'),
    ];
    items.push(this._group('Resumen general', overviewChildren, true, 'pulse'));

    // ── 2. Methods breakdown ─────────────────────────────────────────────
    const byMethod = new Map<string, number>();
    for (const e of eps) byMethod.set(e.method, (byMethod.get(e.method) ?? 0) + 1);

    const methodIcons: Record<string, string> = {
      GET:     'arrow-down',
      POST:    'arrow-up',
      PUT:     'pencil',
      PATCH:   'diff-modified',
      DELETE:  'trash',
      HEAD:    'eye',
      OPTIONS: 'settings-gear',
    };
    const methodColors: Record<string, string> = {
      GET:     'charts.green',
      POST:    'charts.blue',
      PUT:     'charts.yellow',
      PATCH:   'charts.orange',
      DELETE:  'charts.red',
      HEAD:    'charts.purple',
      OPTIONS: 'foreground',
    };

    const methodChildren = [...byMethod.entries()]
      .sort((a, b) => b[1] - a[1])
      .map(([m, c]) => {
        const pct = Math.round((c / total) * 100);
        const filled = Math.round(pct / 10);
        const bar = '█'.repeat(filled) + '░'.repeat(10 - filled);
        return this._stat(m, `${c}  ${bar}  ${pct}%`, methodIcons[m] ?? 'circle-outline', methodColors[m] ?? 'foreground');
      });
    items.push(this._group('Por método HTTP', methodChildren, false, 'graph'));

    // ── 3. Complexity breakdown ──────────────────────────────────────────
    const cxCount = { simple: 0, medium: 0, complex: 0 };
    for (const e of eps) if (e.complexity) cxCount[e.complexity]++;
    const complexityChildren: EndpointItem[] = [
      this._stat(`${COMPLEXITY_ICON.simple}  Simple`,   `${cxCount.simple}`,  'circle-small-filled', 'charts.green'),
      this._stat(`${COMPLEXITY_ICON.medium}  Medium`,   `${cxCount.medium}`,  'circle-filled',       'charts.yellow'),
      this._stat(`${COMPLEXITY_ICON.complex}  Complex`, `${cxCount.complex}`, 'record-small',        'charts.red'),
    ];
    items.push(this._group('Complejidad', complexityChildren, false, 'symbol-misc'));

    // ── 4. Top files ─────────────────────────────────────────────────────
    const byFile = new Map<string, number>();
    for (const e of eps) byFile.set(e.fileName, (byFile.get(e.fileName) ?? 0) + 1);
    const topFiles = [...byFile.entries()]
      .sort((a, b) => b[1] - a[1])
      .slice(0, 5)
      .map(([name, c]) => this._stat(name, `${c} endpoint${c !== 1 ? 's' : ''}`, 'file-code', 'charts.blue'));
    items.push(this._group('Top archivos', topFiles, false, 'list-ordered'));

    // ── 5. Issues ────────────────────────────────────────────────────────
    const problematic = eps.filter(e => (e.issues && e.issues.length > 0) || e.isDuplicate);
    if (problematic.length) {
      const issueChildren = problematic.map(e => {
        const hasErr = e.issues?.some(i => i.type === 'error');
        const it = new EndpointItem(e.functionName, vscode.TreeItemCollapsibleState.None, 'summary');
        it.description = `${e.method}  ${e.fileName}`;
        it.iconPath = new vscode.ThemeIcon(
          hasErr ? 'error' : 'warning',
          new vscode.ThemeColor(hasErr ? 'errorForeground' : 'editorWarning.foreground')
        );
        it.tooltip = e.issues?.map(i => `${i.type}: ${i.message}`).join('\n') ?? 'Duplicado';
        it.command = { command: 'endpointCounter.goToLine', title: 'Ir al endpoint', arguments: [e] };
        return it;
      });
      items.push(this._group(`Problemas (${problematic.length})`, issueChildren, false, 'error'));
    }

    return items;
  }

  // ── helpers ─────────────────────────────────────────────────────────────

  private _group(label: string, children: EndpointItem[], expanded = false, icon = 'pulse'): EndpointItem {
    const it = new EndpointItem(
      label,
      expanded ? vscode.TreeItemCollapsibleState.Expanded : vscode.TreeItemCollapsibleState.Collapsed,
      'summary',
      undefined,
      children
    );
    it.iconPath = new vscode.ThemeIcon(icon);
    return it;
  }

  private _stat(label: string, value: string, icon: string, color: string): EndpointItem {
    const it = new EndpointItem(label, vscode.TreeItemCollapsibleState.None, 'summary');
    it.description = value;
    it.iconPath = new vscode.ThemeIcon(icon, new vscode.ThemeColor(color));
    return it;
  }

  private _empty(): EndpointItem {
    const it = new EndpointItem(
      'Sin endpoints detectados',
      vscode.TreeItemCollapsibleState.None,
      'summary'
    );
    it.iconPath = new vscode.ThemeIcon('info');
    return it;
  }
}