import * as vscode from 'vscode';
import * as fs from 'fs';
import * as path from 'path';
import { Endpoint } from '../types';

const ENDPOINT_REGEX =
  /^\s*@(?:app|router|blueprint|\w+)\.(get|post|put|patch|delete|route)\s*\(\s*['"]([^'"]+)['"]/i;

const FUNCTION_REGEX = /^\s*(?:async\s+)?def\s+(\w+)\s*\(/;

// Detecta el framework según el contenido del archivo
function detectFramework(content: string): 'Flask' | 'FastAPI' | 'Django' | 'Unknown' {
  if (/from\s+fastapi|import\s+fastapi/i.test(content)) return 'FastAPI';
  if (/from\s+flask|import\s+flask/i.test(content)) return 'Flask';
  if (/from\s+django|import\s+django/i.test(content)) return 'Django';
  return 'Unknown';
}

// Extrae el bloque de código fuente de la función (decorador + def + cuerpo)
function extractSourceCode(lines: string[], decoratorLine: number): { source: string; lineEnd: number } {
  let i = decoratorLine;
  // Incluir todos los decoradores consecutivos
  while (i < lines.length && lines[i].trim().startsWith('@')) i++;
  // La línea def
  const defLine = i;
  i++;
  // Recoger el cuerpo indentado
  const baseIndent = lines[defLine]?.match(/^(\s*)/)?.[1]?.length ?? 0;
  while (i < lines.length) {
    const l = lines[i];
    if (l.trim() === '') { i++; continue; }
    const indent = l.match(/^(\s*)/)?.[1]?.length ?? 0;
    if (indent <= baseIndent && l.trim() !== '') break;
    i++;
  }
  const source = lines.slice(decoratorLine, i).join('\n');
  return { source, lineEnd: i };
}

export class EndpointCodeLensProvider implements vscode.CodeLensProvider {
  private _onDidChangeCodeLenses = new vscode.EventEmitter<void>();
  readonly onDidChangeCodeLenses = this._onDidChangeCodeLenses.event;

  public refresh(): void {
    this._onDidChangeCodeLenses.fire();
  }

  provideCodeLenses(document: vscode.TextDocument): vscode.CodeLens[] {
    const config = vscode.workspace.getConfiguration('pypoints');
    if (!config.get<boolean>('enableCodeLens', true)) return [];

    const lenses: vscode.CodeLens[] = [];
    const lines = document.getText().split('\n');
    const fileContent = document.getText();
    const framework = detectFramework(fileContent);
    const filePath = document.uri.fsPath;
    const fileName = path.basename(filePath);

    for (let i = 0; i < lines.length; i++) {
      const match = ENDPOINT_REGEX.exec(lines[i]);
      if (!match) continue;

      const method = match[1].toUpperCase();
      const route = match[2];

      // Buscar nombre de función en las siguientes líneas
      let functionName = 'endpoint';
      let fnLineIdx = i + 1;
      for (let j = i + 1; j < Math.min(i + 5, lines.length); j++) {
        const fnMatch = FUNCTION_REGEX.exec(lines[j]);
        if (fnMatch) { functionName = fnMatch[1]; fnLineIdx = j; break; }
      }

      // Extraer código fuente real
      const { source, lineEnd } = extractSourceCode(lines, i);
      const lineCount = lineEnd - i;

      // Construir Endpoint completo y compatible con buildPreviewHtml
      const endpoint: Endpoint = {
        method,
        route,
        functionName,
        filePath,
        fileName,
        lineStart: i + 1,       // 1-based
        lineEnd: lineEnd,
        lineCount,
        framework,
        category: fileName,
        sourceCode: source,
        complexity: lineCount > 30 ? 'complex' : lineCount > 15 ? 'medium' : 'simple',
        issues: [],
        isDuplicate: false,
        duplicateOf: undefined,
        code: source,
      };

      const range = new vscode.Range(i, 0, i, 0);


      
      lenses.push(new vscode.CodeLens(range, {
        title: 'Test',
        tooltip: `Testear: ${method} ${route}`,
        command: 'pypoints.codeLensRun',
        arguments: [endpoint],
      }));

      lenses.push(new vscode.CodeLens(range, {
        title: '⎘ Ruta',
        tooltip: `Copiar ruta: ${route}`,
        command: 'pypoints.codeLensCopyRoute',
        arguments: [route],
      }));

      lenses.push(new vscode.CodeLens(range, {
        title: '⎘ cURL',
        tooltip: `Copiar cURL: ${method} ${route}`,
        command: 'pypoints.codeLensCopyCurl',
        arguments: [method, route],
      }));
    }

    return lenses;
  }
}