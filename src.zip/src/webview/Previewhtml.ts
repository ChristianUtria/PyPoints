import * as vscode from 'vscode';
import { Endpoint, ServerConfig } from '../types';
import { COMPLEXITY_ICON } from '../utils/complexity';
import { buildCandidateUrls } from '../server/Urlbuilder';

// El JS del webview se construye con concatenación de strings normales,
// nunca con template literals anidados, para evitar SyntaxError al compilar.
function buildClientScript(
  ep: Endpoint,
  detectedUrl: string,
  routeParams: string[],
  hasBodyByDefault: boolean,
  epHistJson: string,
  globalHistJson: string,
  badgeColor: string
): string {
  const BR  = JSON.stringify(ep.route);
  const RP  = JSON.stringify(routeParams);
  const DU  = JSON.stringify(detectedUrl);
  const EM  = JSON.stringify(ep.method);

  return '' +
'const vscode = acquireVsCodeApi();\n' +
'let activeTab = "test";\n' +
'const BASE_ROUTE = ' + BR + ';\n' +
'const ROUTE_PARAMS = ' + RP + ';\n' +
'const DETECTED_URL = ' + DU + ';\n' +
'const EP_METHOD = ' + EM + ';\n' +
'const MC = {GET:"#22c55e",POST:"#3b82f6",PUT:"#eab308",PATCH:"#f97316",DELETE:"#ef4444",HEAD:"#a855f7",OPTIONS:"#6b7280"};\n' +
'let epHistory = ' + epHistJson + ';\n' +
'let globalHistory = ' + globalHistJson + ';\n' +
'\n' +
'window.addEventListener("load", function() {\n' +
'  pingServer(); updateUrlPreview(); updateMethodColor(); updateBodyVisibility();\n' +
'  renderEndpointHistory(); renderGlobalHistory();\n' +
'  var ta=document.getElementById("bodyInput"); if(ta){autoResize(ta);updateGutter();}\n' +
'});\n' +
'\n' +
'function switchTab(tab, btn) {\n' +
'  activeTab = tab;\n' +
'  document.querySelectorAll(".tab-content").forEach(function(e){e.classList.remove("active");});\n' +
'  document.querySelectorAll(".tab-btn").forEach(function(e){e.classList.remove("active");});\n' +
'  var tc = document.getElementById("tab-"+tab);\n' +
'  if (tc) { tc.classList.add("active"); }\n' +
'  if (btn) { btn.classList.add("active"); }\n' +
'  if (tab==="test")   { pingServer(); updateUrlPreview(); }\n' +
'  if (tab==="curl")   { updateCurlPreview(); }\n' +
'  if (tab==="global") { renderGlobalHistory(); }\n' +
'}\n' +
'\n' +
'function copyActive() {\n' +
'  var text = "";\n' +
'  if (activeTab==="curl") { text = buildCurlCommand(); }\n' +
'  else { var el = document.getElementById("code-"+activeTab); text = el ? el.innerText : ""; }\n' +
'  if (!text) { return; }\n' +
'  navigator.clipboard.writeText(text).then(function() {\n' +
'    var btn = document.getElementById("copyBtn"); var orig = btn.innerHTML;\n' +
'    btn.innerHTML = "Copiado"; btn.classList.add("copied");\n' +
'    setTimeout(function(){ btn.innerHTML = orig; btn.classList.remove("copied"); }, 2000);\n' +
'  });\n' +
'}\n' +
'\n' +
'function getCurrentMethod() {\n' +
'  var s = document.getElementById("methodSelect");\n' +
'  return (s ? s.value : EP_METHOD).toUpperCase();\n' +
'}\n' +
'function onMethodChange() { updateMethodColor(); updateBodyVisibility(); updateCurlPreview(); }\n' +
'function updateMethodColor() {\n' +
'  var s = document.getElementById("methodSelect"); if (!s) { return; }\n' +
'  var c = MC[s.value.toUpperCase()] || "#888";\n' +
'  s.style.color = c; s.style.borderColor = c+"88";\n' +
'}\n' +
'function updateBodyVisibility() {\n' +
'  var m = getCurrentMethod();\n' +
'  var wb = ["POST","PUT","PATCH"].indexOf(m) !== -1;\n' +
'  var hint = document.getElementById("bodyMethodHint");\n' +
'  if (hint) { hint.textContent = wb ? "" : "(no aplica para "+m+")"; }\n' +
'  var bc = document.getElementById("bodyContent");\n' +
'  var ar = document.querySelector("#bodySection .c-arrow");\n' +
'  if (bc && ar) {\n' +
'    if (wb) { bc.classList.remove("closed"); ar.classList.add("open"); }\n' +
'    else    { bc.classList.add("closed");    ar.classList.remove("open"); }\n' +
'  }\n' +
'}\n' +
'\n' +
'async function pingServer() {\n' +
'  var dot = document.getElementById("serverDot");\n' +
'  var lbl = document.getElementById("serverUrlLabel");\n' +
'  var base = getBase();\n' +
'  dot.className = "server-dot checking"; lbl.textContent = base;\n' +
'  try {\n' +
'    var ctrl = new AbortController();\n' +
'    var t = setTimeout(function(){ ctrl.abort(); }, 3000);\n' +
'    await fetch(base+"/", { method:"GET", signal:ctrl.signal, mode:"no-cors" });\n' +
'    clearTimeout(t); dot.className = "server-dot live";\n' +
'  } catch(e) {\n' +
'    dot.className = e.name==="AbortError" ? "server-dot dead" : "server-dot live";\n' +
'  }\n' +
'}\n' +
'\n' +
'function getBase() {\n' +
'  var s = document.getElementById("baseUrlSelect"); if (!s) { return DETECTED_URL; }\n' +
'  if (s.value==="__custom__") { return DETECTED_URL; }\n' +
'  return s.value.replace(/\\/+$/, "");\n' +
'}\n' +
'function onBaseChange() {\n' +
'  var s = document.getElementById("baseUrlSelect");\n' +
'  if (s.value==="__custom__") {\n' +
'    var val = prompt("URL base del servidor:", DETECTED_URL);\n' +
'    if (val) {\n' +
'      var opt = document.createElement("option");\n' +
'      opt.value = val; opt.textContent = val; opt.selected = true;\n' +
'      s.insertBefore(opt, s.lastElementChild);\n' +
'    } else { s.value = DETECTED_URL; }\n' +
'  }\n' +
'  document.getElementById("serverUrlLabel").textContent = getBase();\n' +
'  updateUrlPreview(); pingServer();\n' +
'}\n' +
'\n' +
'function buildUrl() {\n' +
'  var base = getBase();\n' +
'  var re = document.getElementById("routeEditable");\n' +
'  var route = re ? re.value : BASE_ROUTE;\n' +
'  for (var i=0; i<ROUTE_PARAMS.length; i++) {\n' +
'    var p = ROUTE_PARAMS[i];\n' +
'    var inp = document.getElementById("param-"+p);\n' +
'    var val = encodeURIComponent(inp ? inp.value : p);\n' +
'    route = route.replace(new RegExp("<(?:\\\\w+:)?"+p+">","g"), val)\n' +
'                 .replace(new RegExp("\\\\{"+p+"\\\\}","g"), val);\n' +
'  }\n' +
'  var rows = document.querySelectorAll("#qBuilder .query-row");\n' +
'  var params = [];\n' +
'  for (var j=0; j<rows.length; j++) {\n' +
'    var ins = rows[j].querySelectorAll(".query-input");\n' +
'    var k = ins[0] ? ins[0].value.trim() : "";\n' +
'    var v = ins[1] ? ins[1].value.trim() : "";\n' +
'    if (k) { params.push(encodeURIComponent(k)+"="+encodeURIComponent(v)); }\n' +
'  }\n' +
'  return resolveVars(base + route + (params.length ? "?"+params.join("&") : ""));\n' +
'}\n' +
'function updateUrlPreview() {\n' +
'  var url = buildUrl();\n' +
'  var el = document.getElementById("urlPreview");\n' +
'  if (el) { el.textContent = url; el.classList.toggle("has-params", url !== DETECTED_URL+BASE_ROUTE); }\n' +
'}\n' +
'\n' +
'function buildCurlCommand() {\n' +
'  var url = buildUrl(); var method = getCurrentMethod();\n' +
'  var headers = getHeaders();\n' +
'  var wb = ["POST","PUT","PATCH"].indexOf(method) !== -1;\n' +
'  var fe = document.getElementById("bodyFormat"); var format = fe ? fe.value : "json";\n' +
'  var te = document.getElementById("bodyTextarea"); var bodyText = te ? te.value.trim() : "";\n' +
'  var hParts = [];\n' +
'  Object.keys(headers).forEach(function(k){ hParts.push(" \\\\\\n  -H \\""+k+": "+headers[k]+"\\""); });\n' +
'  var h = hParts.join("");\n' +
'  var bp = "";\n' +
'  if (wb && format!=="none") {\n' +
'    if (format==="json") {\n' +
'      if (h.indexOf("Content-Type")===-1) { h += " \\\\\\n  -H \\"Content-Type: application/json\\""; }\n' +
'      bp = " \\\\\\n  -d \'"+(bodyText||"{}").replace(/\'/g,"\\\'")+"\'"; }\n' +
'    else if (format==="form") {\n' +
'      if (h.indexOf("Content-Type")===-1) { h += " \\\\\\n  -H \\"Content-Type: application/x-www-form-urlencoded\\""; }\n' +
'      if (bodyText) { bp = " \\\\\\n  --data-urlencode \'"+bodyText+"\'"; } }\n' +
'    else if (format==="text") {\n' +
'      if (h.indexOf("Content-Type")===-1) { h += " \\\\\\n  -H \\"Content-Type: text/plain\\""; }\n' +
'      if (bodyText) { bp = " \\\\\\n  -d \'"+bodyText.replace(/\'/g,"\\\'")+"\'"; } }\n' +
'  }\n' +
'  return "curl -X "+method+" \\""+url+"\\""+h+bp;\n' +
'}\n' +
'function updateCurlPreview() {\n' +
'  var el = document.getElementById("code-curl");\n' +
'  if (el) { el.textContent = buildCurlCommand(); }\n' +
'}\n' +
'\n' +
'// ── Editor rico ───────────────────────────────────────────────────────────\n' +
'function getBodyText() {\n' +
'  var ta=document.getElementById("bodyInput"); return ta?ta.value:"";\n' +
'}\n' +
'function setBodyText(val) {\n' +
'  var ta=document.getElementById("bodyInput"); if(!ta){return;}\n' +
'  ta.value=val; autoResize(ta); updateGutter(); validateBody(); updateCurlPreview();\n' +
'}\n' +
'function autoResize(ta) {\n' +
'  ta.style.height="auto";\n' +
'  ta.style.height=(ta.scrollHeight)+"px";\n' +
'}\n' +
'\n' +
'function updateGutter() {\n' +
'  var ta=document.getElementById("bodyInput");\n' +
'  var gutter=document.getElementById("bodyGutter");\n' +
'  if(!ta||!gutter){return;}\n' +
'  autoResize(ta);\n' +
'  var lines=ta.value.split("\\n");\n' +
'  var curLine=ta.value.substr(0,ta.selectionStart).split("\\n").length;\n' +
'  var html="";\n' +
'  for(var i=1;i<=Math.max(lines.length,1);i++){\n' +
'    html+="<span"+(i===curLine?" class=\\"active-ln\\"":"")+">"+i+"</span>";\n' +
'  }\n' +
'  gutter.innerHTML=html;\n' +
'}\n' +
'\n' +
'function onBodyFormatChange() {\n' +
'  var fe=document.getElementById("bodyFormat"); var fmt=fe?fe.value:"";\n' +
'  var wrap=document.getElementById("bodyEditorWrap");\n' +
'  if(fmt==="none"){if(wrap){wrap.style.display="none";}return;}\n' +
'  if(wrap){wrap.style.display="flex";}\n' +
'  validateBody();\n' +
'}\n' +
'\n' +
'function validateBody() {\n' +
'  var fe=document.getElementById("bodyFormat"); var fmt=fe?fe.value:"";\n' +
'  var badge=document.getElementById("bodyValidation");\n' +
'  if(!badge||fmt!=="json"){if(badge){badge.className="body-validation";badge.textContent="";}return;}\n' +
'  var val=getBodyText().trim();\n' +
'  if(!val){badge.className="body-validation";badge.textContent="";return;}\n' +
'  try{JSON.parse(val);badge.className="body-validation body-valid";badge.textContent="JSON valido";}\n' +
'  catch(e){badge.className="body-validation body-invalid";badge.textContent="Error: "+e.message.split("\\n")[0];}\n' +
'}\n' +
'\n' +
'function formatBody() {\n' +
'  var val=getBodyText();\n' +
'  try{setBodyText(JSON.stringify(JSON.parse(val),null,2));toast("JSON formateado");}\n' +
'  catch(e){toast("No es JSON valido");}\n' +
'}\n' +
'function clearBody() { setBodyText(""); }\n' +
'function copyBody()  { navigator.clipboard.writeText(getBodyText()); toast("Body copiado"); }\n' +
'\n' +
'// pares de autocomplete\n' +
'var PAIRS={};\n' +
'PAIRS[\'"\'] = \'"\';\n' +
'PAIRS["{"] = "}";\n' +
'PAIRS["["] = "]";\n' +
'PAIRS["("] = ")";\n' +
'var CLOSERS={"}":{o:"{"},"]":{o:"["},")": {o:"("}};\n' +
'\n' +
'function handleBodyKeydown(e) {\n' +
'  var ta=e.target;\n' +
'  var s=ta.selectionStart; var en=ta.selectionEnd;\n' +
'\n' +
'  // Tab / Shift+Tab\n' +
'  if(e.key==="Tab"){\n' +
'    e.preventDefault(); var sp="  ";\n' +
'    if(s!==en){\n' +
'      var val=ta.value;\n' +
'      var ls=val.lastIndexOf("\\n",s-1)+1;\n' +
'      var le=val.indexOf("\\n",en);\n' +
'      var blk=val.slice(ls,le===-1?undefined:le);\n' +
'      if(e.shiftKey){\n' +
'        var ded=blk.replace(/^  /gm,"");\n' +
'        ta.value=val.slice(0,ls)+ded+(le===-1?"":val.slice(le));\n' +
'        ta.selectionStart=ls;ta.selectionEnd=ls+ded.length;\n' +
'      }else{\n' +
'        var ind=blk.replace(/^/gm,sp);\n' +
'        ta.value=val.slice(0,ls)+ind+(le===-1?"":val.slice(le));\n' +
'        ta.selectionStart=ls;ta.selectionEnd=ls+ind.length;\n' +
'      }\n' +
'    }else{\n' +
'      ta.value=ta.value.slice(0,s)+sp+ta.value.slice(en);\n' +
'      ta.selectionStart=ta.selectionEnd=s+sp.length;\n' +
'    }\n' +
'    updateGutter();validateBody();return;\n' +
'  }\n' +
'\n' +
'  // Saltar sobre cierre si ya existe\n' +
'  if(CLOSERS[e.key]&&s===en&&ta.value[s]===e.key){\n' +
'    e.preventDefault();\n' +
'    ta.selectionStart=ta.selectionEnd=s+1;\n' +
'    updateGutter();return;\n' +
'  }\n' +
'\n' +
'  // Autoclose de pares\n' +
'  var close=PAIRS[e.key];\n' +
'  if(close){\n' +
'    e.preventDefault();\n' +
'    var sel=ta.value.slice(s,en);\n' +
'    // Si hay texto seleccionado, envuélvelo\n' +
'    var ins=e.key+sel+close;\n' +
'    ta.value=ta.value.slice(0,s)+ins+ta.value.slice(en);\n' +
'    // Cursor entre los pares\n' +
'    ta.selectionStart=ta.selectionEnd=s+1+(sel.length>0?sel.length:0);\n' +
'    updateGutter();validateBody();return;\n' +
'  }\n' +
'\n' +
'  // Enter con sangria inteligente\n' +
'  if(e.key==="Enter"&&s===en){\n' +
'    e.preventDefault();\n' +
'    var before=ta.value.slice(0,s);\n' +
'    var after=ta.value.slice(s);\n' +
'    var lastLine=before.slice(before.lastIndexOf("\\n")+1);\n' +
'    var indent=lastLine.match(/^(\\s*)/)[1];\n' +
'    var lastChar=before.trimEnd().slice(-1);\n' +
'    var firstChar=after.trimStart().charAt(0);\n' +
'    var openBracket=(lastChar==="{"||lastChar==="[");\n' +
'    var closeBracket=(firstChar==="}"||firstChar==="]");\n' +
'    if(openBracket&&closeBracket){\n' +
'      // Enter entre {} o []: sangria doble + cursor en medio\n' +
'      var ins="\\n"+indent+"  "+"\\n"+indent;\n' +
'      ta.value=before+ins+after;\n' +
'      ta.selectionStart=ta.selectionEnd=s+indent.length+3;\n' +
'    }else{\n' +
'      var extra=openBracket?"  ":"";\n' +
'      var ins="\\n"+indent+extra;\n' +
'      ta.value=before+ins+after;\n' +
'      ta.selectionStart=ta.selectionEnd=s+ins.length;\n' +
'    }\n' +
'    updateGutter();validateBody();return;\n' +
'  }\n' +
'\n' +
'  // Backspace: borrar par si el cursor está entre ellos\n' +
'  if(e.key==="Backspace"&&s===en&&s>0){\n' +
'    var ch=ta.value[s-1];\n' +
'    var nxt=ta.value[s];\n' +
'    if(PAIRS[ch]&&PAIRS[ch]===nxt){\n' +
'      e.preventDefault();\n' +
'      ta.value=ta.value.slice(0,s-1)+ta.value.slice(s+1);\n' +
'      ta.selectionStart=ta.selectionEnd=s-1;\n' +
'      updateGutter();validateBody();return;\n' +
'    }\n' +
'  }\n' +
'\n' +
'  setTimeout(function(){updateGutter();validateBody();},0);\n' +
'}\n' +
'\n' +
'function addQRow() {\n' +
'  var d=document.createElement("div"); d.className="query-row";\n' +
'  d.innerHTML="<input class=\\"query-input\\" placeholder=\\"clave\\" oninput=\\"updateUrlPreview()\\"/>"+\n' +
'    "<span class=\\"sep\\">=</span>"+\n' +
'    "<input class=\\"query-input\\" placeholder=\\"valor\\" oninput=\\"updateUrlPreview()\\"/>"+\n' +
'    "<button class=\\"icon-btn\\" onclick=\\"rmRow(this,\'.query-row\')\\">&#x2212;</button>";\n' +
'  document.getElementById("qBuilder").appendChild(d);\n' +
'}\n' +
'function addHRow() {\n' +
'  var d=document.createElement("div"); d.className="header-row";\n' +
'  d.innerHTML="<input class=\\"header-input\\" placeholder=\\"Header-Name\\"/>"+\n' +
'    "<span class=\\"sep\\">:</span>"+\n' +
'    "<input class=\\"header-input\\" placeholder=\\"valor\\"/>"+\n' +
'    "<button class=\\"icon-btn\\" onclick=\\"rmRow(this,\'.header-row\')\\">&#x2212;</button>";\n' +
'  document.getElementById("hBuilder").appendChild(d);\n' +
'}\n' +
'function rmRow(btn,sel) { btn.closest(sel).remove(); updateUrlPreview(); }\n' +
'function toggle(id,btn) {\n' +
'  var el=document.getElementById(id); var ar=btn.querySelector(".c-arrow");\n' +
'  if (el.classList.contains("closed")) { el.classList.remove("closed"); ar.classList.add("open"); }\n' +
'  else { el.classList.add("closed"); ar.classList.remove("open"); }\n' +
'}\n' +
'\n' +
'function copyFullUrl()  { navigator.clipboard.writeText(resolveVars(buildUrl()));         toast("URL copiada"); }\n' +
'function copyCurlFull() { navigator.clipboard.writeText(buildCurlCommand()); toast("cURL copiado"); }\n' +
'function openBrowser()  { vscode.postMessage({ command:"openExternal", url:resolveVars(buildUrl()) }); }\n' +
'function toast(msg) {\n' +
'  var t=document.getElementById("toast");\n' +
'  t.textContent=msg; t.style.display="block";\n' +
'  setTimeout(function(){ t.style.display="none"; },2000);\n' +
'}\n' +
'\n' +
'// ── Variables de entorno ──────────────────────────────────────────────────\n' +
'var envVars = {};\n' +
'function resolveVars(str) {\n' +
'  if (!str) { return str; }\n' +
'  return str.replace(/\\{\\{([\\w_]+)\\}\\}/g, function(m,k){ return envVars[k]!==undefined?envVars[k]:m; });\n' +
'}\n' +
'function renderEnvBuilder() {\n' +
'  var b=document.getElementById("envBuilder"); var cnt=document.getElementById("envCount");\n' +
'  if(!b){return;}\n' +
'  var keys=Object.keys(envVars);\n' +
'  if(cnt){cnt.textContent=keys.length?"("+keys.length+")":"";}  \n' +
'  var html="";\n' +
'  keys.forEach(function(k){\n' +
'    html+="<div class=\\"header-row\\" style=\\"margin-bottom:5px;\\">"+\n' +
'      "<input class=\\"header-input\\" placeholder=\\"NOMBRE\\" value=\\""+k+"\\" style=\\"font-weight:600;color:' + badgeColor + ';\\" onchange=\\"saveEnvVars()\\"/>"+\n' +
'      "<span class=\\"sep\\">=</span>"+\n' +
'      "<input class=\\"header-input\\" placeholder=\\"valor\\" value=\\""+envVars[k].replace(/"/g,"&quot;")+"\\" type=\\"password\\" style=\\"font-family:monospace;\\" onchange=\\"saveEnvVars()\\"/>"+\n' +
'      "<button class=\\"icon-btn\\" style=\\"font-size:10px;\\" onclick=\\"toggleEnvVis(this)\\" title=\\"Ver/ocultar\\">&#x25CE;</button>"+\n' +
'      "<button class=\\"icon-btn\\" onclick=\\"rmEnvRow(this)\\">&#x2212;</button></div>";\n' +
'  });\n' +
'  b.innerHTML=html;\n' +
'}\n' +
'function addEnvRow() {\n' +
'  var b=document.getElementById("envBuilder"); if(!b){return;}\n' +
'  var d=document.createElement("div"); d.className="header-row"; d.style.marginBottom="5px";\n' +
'  d.innerHTML="<input class=\\"header-input\\" placeholder=\\"NOMBRE\\" style=\\"font-weight:600;color:' + badgeColor + ';\\" onchange=\\"saveEnvVars()\\"/>"+\n' +
'    "<span class=\\"sep\\">=</span>"+\n' +
'    "<input class=\\"header-input\\" placeholder=\\"valor\\" type=\\"password\\" style=\\"font-family:monospace;\\" onchange=\\"saveEnvVars()\\"/>"+\n' +
'    "<button class=\\"icon-btn\\" style=\\"font-size:10px;\\" onclick=\\"toggleEnvVis(this)\\" title=\\"Ver/ocultar\\">&#x25CE;</button>"+\n' +
'    "<button class=\\"icon-btn\\" onclick=\\"rmEnvRow(this)\\">&#x2212;</button>";\n' +
'  b.appendChild(d);\n' +
'}\n' +
'function toggleEnvVis(btn) {\n' +
'  var row=btn.closest(".header-row"); var inp=row.querySelectorAll(".header-input")[1];\n' +
'  if(inp){inp.type=inp.type==="password"?"text":"password";}\n' +
'}\n' +
'function rmEnvRow(btn) {\n' +
'  var row=btn.closest(".header-row"); var ins=row.querySelectorAll(".header-input");\n' +
'  var k=ins[0]?ins[0].value.trim():"";\n' +
'  if(k){delete envVars[k];}\n' +
'  row.remove();\n' +
'  var cnt=document.getElementById("envCount");\n' +
'  if(cnt){var ks=Object.keys(envVars);cnt.textContent=ks.length?"("+ks.length+")":"";}  \n' +
'}\n' +
'function saveEnvVars() {\n' +
'  var b=document.getElementById("envBuilder"); if(!b){return;}\n' +
'  envVars={};\n' +
'  b.querySelectorAll(".header-row").forEach(function(row){\n' +
'    var ins=row.querySelectorAll(".header-input");\n' +
'    var k=ins[0]?ins[0].value.trim():""; var v=ins[1]?ins[1].value:"";\n' +
'    if(k){envVars[k]=v;}\n' +
'  });\n' +
'  var cnt=document.getElementById("envCount");\n' +
'  if(cnt){var ks=Object.keys(envVars);cnt.textContent=ks.length?"("+ks.length+")":"";}  \n' +
'  toast("Variables guardadas"); updateUrlPreview();\n' +
'}\n' +
'function loadEnvTemplate() {\n' +
'  envVars={TOKEN:"",API_KEY:"",BASE_URL:DETECTED_URL,SECRET:""};\n' +
'  renderEnvBuilder(); toast("Plantilla .env cargada");\n' +
'}\n' +
'\n' +
'// ── Auth ──────────────────────────────────────────────────────────────────\n' +
'function onAuthTypeChange() {\n' +
'  var sel=document.getElementById("authType"); if(!sel){return;}\n' +
'  var type=sel.value;\n' +
'  var fields=document.getElementById("authFields");\n' +
'  var preview=document.getElementById("authPreview");\n' +
'  var badge=document.getElementById("authBadge");\n' +
'  if(!fields){return;}\n' +
'  if(type==="none"){\n' +
'    fields.innerHTML=""; if(preview){preview.style.display="none";} if(badge){badge.style.display="none";} return;\n' +
'  }\n' +
'  var html="";\n' +
'  if(type==="bearer"){\n' +
'    html="<div class=\\"param-row\\">"+\n' +
'      "<label class=\\"param-label\\" style=\\"color:' + badgeColor + '\\">Token</label>"+\n' +
'      "<input class=\\"param-input\\" id=\\"authToken\\" type=\\"password\\" placeholder=\\"eyJhbGci... o {{TOKEN}}\\" oninput=\\"updateAuthPreview()\\"/>"+\n' +
'      "<button class=\\"icon-btn\\" data-vis=\\"authToken\\" onclick=\\"toggleAuthVis(this)\\" title=\\"Ver\\">&#x25CE;</button>"+\n' +
'      "</div>"+\n' +
'      "<div style=\\"font-size:9px;color:var(--vscode-descriptionForeground);margin-top:4px;margin-left:88px;\\">"+\n' +
'      "Genera header <code style=\\"background:rgba(128,128,128,.15);padding:1px 4px;border-radius:2px;\\">Authorization: Bearer &lt;token&gt;</code></div>";\n' +
'  } else if(type==="basic"){\n' +
'    html="<div class=\\"param-row\\">"+\n' +
'      "<label class=\\"param-label\\" style=\\"color:' + badgeColor + '\\">Usuario</label>"+\n' +
'      "<input class=\\"param-input\\" id=\\"authUser\\" type=\\"text\\" placeholder=\\"user o {{USER}}\\" oninput=\\"updateAuthPreview()\\"/>"+\n' +
'      "</div>"+\n' +
'      "<div class=\\"param-row\\" style=\\"margin-top:5px;\\">"+\n' +
'      "<label class=\\"param-label\\" style=\\"color:' + badgeColor + '\\">Password</label>"+\n' +
'      "<input class=\\"param-input\\" id=\\"authPass\\" type=\\"password\\" placeholder=\\"pass o {{PASSWORD}}\\" oninput=\\"updateAuthPreview()\\"/>"+\n' +
'      "<button class=\\"icon-btn\\" data-vis=\\"authPass\\" onclick=\\"toggleAuthVis(this)\\" title=\\"Ver\\">&#x25CE;</button>"+\n' +
'      "</div>";\n' +
'  } else if(type==="apikey"){\n' +
'    html="<div class=\\"param-row\\">"+\n' +
'      "<label class=\\"param-label\\" style=\\"color:' + badgeColor + '\\">Header</label>"+\n' +
'      "<input class=\\"param-input\\" id=\\"authKeyName\\" type=\\"text\\" placeholder=\\"X-API-Key\\" value=\\"X-API-Key\\" oninput=\\"updateAuthPreview()\\"/>"+\n' +
'      "</div>"+\n' +
'      "<div class=\\"param-row\\" style=\\"margin-top:5px;\\">"+\n' +
'      "<label class=\\"param-label\\" style=\\"color:' + badgeColor + '\\">Valor</label>"+\n' +
'      "<input class=\\"param-input\\" id=\\"authKeyVal\\" type=\\"password\\" placeholder=\\"tu-api-key o {{API_KEY}}\\" oninput=\\"updateAuthPreview()\\"/>"+\n' +
'      "<button class=\\"icon-btn\\" data-vis=\\"authKeyVal\\" onclick=\\"toggleAuthVis(this)\\" title=\\"Ver\\">&#x25CE;</button>"+\n' +
'      "</div>";\n' +
'  } else if(type==="custom"){\n' +
'    html="<div class=\\"param-row\\">"+\n' +
'      "<label class=\\"param-label\\" style=\\"color:' + badgeColor + '\\">Header</label>"+\n' +
'      "<input class=\\"param-input\\" id=\\"authCustomName\\" type=\\"text\\" placeholder=\\"Authorization\\" value=\\"Authorization\\" oninput=\\"updateAuthPreview()\\"/>"+\n' +
'      "</div>"+\n' +
'      "<div class=\\"param-row\\" style=\\"margin-top:5px;\\">"+\n' +
'      "<label class=\\"param-label\\" style=\\"color:' + badgeColor + '\\">Valor</label>"+\n' +
'      "<input class=\\"param-input\\" id=\\"authCustomVal\\" type=\\"text\\" placeholder=\\"Token xyz o {{CUSTOM}}\\" oninput=\\"updateAuthPreview()\\"/>"+\n' +
'      "</div>";\n' +
'  }\n' +
'  fields.innerHTML=html;\n' +
'  if(badge){badge.textContent=type.toUpperCase();badge.style.display="inline";}\n' +
'  if(preview){preview.style.display="block";}\n' +
'  updateAuthPreview();\n' +
'}\n' +
'function toggleAuthVis(id) {\n' +
'  var el=document.getElementById(id); if(!el){return;}\n' +
'  el.type=el.type==="password"?"text":"password";\n' +
'}\n' +
'function updateAuthPreview() {\n' +
'  var preview=document.getElementById("authPreview"); if(!preview){return;}\n' +
'  var h=getAuthHeader();\n' +
'  if(!h){preview.style.display="none";return;}\n' +
'  var mv=h.value.length>24?h.value.slice(0,10)+"&hellip;"+h.value.slice(-4):h.value;\n' +
'  preview.style.display="block";\n' +
'  preview.innerHTML="<span style=\\"color:#7dd3fc\\">"+h.key+"</span>"+\n' +
'    "<span style=\\"opacity:.4\\">: </span>"+\n' +
'    "<span style=\\"color:#86efac\\">"+mv+"</span>";\n' +
'}\n' +
'function getAuthHeader() {\n' +
'  var sel=document.getElementById("authType"); if(!sel){return null;}\n' +
'  var type=sel.value;\n' +
'  if(type==="none"){return null;}\n' +
'  if(type==="bearer"){\n' +
'    var tok=document.getElementById("authToken"); if(!tok||!tok.value.trim()){return null;}\n' +
'    return {key:"Authorization",value:"Bearer "+resolveVars(tok.value.trim())};\n' +
'  }\n' +
'  if(type==="basic"){\n' +
'    var u=document.getElementById("authUser"); var p=document.getElementById("authPass");\n' +
'    if(!u||!u.value.trim()){return null;}\n' +
'    return {key:"Authorization",value:"Basic "+btoa(resolveVars(u.value.trim())+":"+(p?resolveVars(p.value):""))};\n' +
'  }\n' +
'  if(type==="apikey"){\n' +
'    var kn=document.getElementById("authKeyName"); var kv=document.getElementById("authKeyVal");\n' +
'    if(!kn||!kn.value.trim()||!kv||!kv.value.trim()){return null;}\n' +
'    return {key:resolveVars(kn.value.trim()),value:resolveVars(kv.value.trim())};\n' +
'  }\n' +
'  if(type==="custom"){\n' +
'    var cn=document.getElementById("authCustomName"); var cv=document.getElementById("authCustomVal");\n' +
'    if(!cn||!cn.value.trim()){return null;}\n' +
'    return {key:resolveVars(cn.value.trim()),value:resolveVars(cv?cv.value:"")};\n' +
'  }\n' +
'  return null;\n' +
'}\n' +
'\n' +
'function getHeaders() {\n' +
'  var h={};\n' +
'  document.querySelectorAll("#hBuilder .header-row").forEach(function(row){\n' +
'    var ins=row.querySelectorAll(".header-input");\n' +
'    var k=ins[0]?ins[0].value.trim():""; var v=ins[1]?ins[1].value.trim():"";\n' +
'    if(k){h[resolveVars(k)]=resolveVars(v);}\n' +
'  });\n' +
'  // Inyectar auth header (tiene prioridad sobre headers manuales)\n' +
'  var auth=getAuthHeader();\n' +
'  if(auth){h[auth.key]=auth.value;}\n' +
'  return h;\n' +
'}\n' +
'\n' +
'function buildFetchOptions() {\n' +
'  var method=getCurrentMethod(); var headers=getHeaders();\n' +
'  var wb=["POST","PUT","PATCH"].indexOf(method)!==-1;\n' +
'  var fe=document.getElementById("bodyFormat"); var format=fe?fe.value:"json";\n' +
'  var bodyText=getBodyText().trim();\n' +
'  var opts={method:method,headers:Object.assign({},headers)};\n' +
'  if (wb && format!=="none") {\n' +
'    if (format==="json") { opts.headers["Content-Type"]=opts.headers["Content-Type"]||"application/json"; opts.body=bodyText||"{}"; }\n' +
'    else if (format==="form") { opts.headers["Content-Type"]=opts.headers["Content-Type"]||"application/x-www-form-urlencoded"; opts.body=bodyText; }\n' +
'    else if (format==="text") { opts.headers["Content-Type"]=opts.headers["Content-Type"]||"text/plain"; opts.body=bodyText; }\n' +
'  }\n' +
'  return opts;\n' +
'}\n' +
'\n' +
'function hlJson(json) {\n' +
'  if (typeof json!=="string") { json=JSON.stringify(json,null,2); }\n' +
'  return json.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;")\n' +
'    .replace(/(\"(\\\\u[a-zA-Z0-9]{4}|\\\\[^u]|[^\\\\\"])*\"(\\s*:)?|\\b(true|false|null)\\b|-?\\d+(?:\\.\\d*)?(?:[eE][+\\-]?\\d+)?)/g,function(m){\n' +
'      var c="jn";\n' +
'      if(/^"/.test(m)){c=/:$/.test(m)?"jk":"js";}\n' +
'      else if(/true|false/.test(m)){c="jb";}\n' +
'      else if(/null/.test(m)){c="jnull";}\n' +
'      return "<span class=\\""+c+"\\">"+m+"</span>";\n' +
'    });\n' +
'}\n' +
'\n' +
'function validate(status,body,elapsed,method) {\n' +
'  var checks=[];\n' +
'  if(status>=200&&status<300){checks.push({ok:true,msg:"HTTP "+status+" - respuesta exitosa"});}\n' +
'  else if(status===405){checks.push({ok:false,msg:"HTTP 405 - Metodo "+method+" no permitido"});}\n' +
'  else if(status>=400&&status<500){checks.push({ok:false,msg:"HTTP "+status+" - error del cliente"});}\n' +
'  else if(status>=500){checks.push({ok:false,msg:"HTTP "+status+" - error del servidor"});}\n' +
'  if(elapsed>2000){checks.push({ok:null,msg:"Respuesta lenta: "+elapsed+"ms"});}\n' +
'  else if(elapsed>500){checks.push({ok:null,msg:"Tiempo aceptable: "+elapsed+"ms"});}\n' +
'  else{checks.push({ok:true,msg:"Respuesta rapida: "+elapsed+"ms"});}\n' +
'  try {\n' +
'    var p=JSON.parse(body);\n' +
'    if(Array.isArray(p)){checks.push({ok:true,msg:"JSON valido - array ["+p.length+" elem.]"});}\n' +
'    else if(p&&typeof p==="object"){checks.push({ok:true,msg:"JSON valido - objeto {"+Object.keys(p).length+" claves}"});}\n' +
'    else{checks.push({ok:null,msg:"JSON primitivo ("+typeof p+")"}); }\n' +
'  } catch(ex){\n' +
'    var t=body.trim();\n' +
'    if(t.charAt(0)==="<"){checks.push({ok:null,msg:"Respuesta HTML/XML"});}\n' +
'    else if(t===""){checks.push({ok:null,msg:"Body vacio"});}\n' +
'    else{checks.push({ok:null,msg:"Texto plano"});}\n' +
'  }\n' +
'  return checks;\n' +
'}\n' +
'function renderValidation(checks) {\n' +
'  return checks.map(function(c){\n' +
'    var cls=c.ok===true?"v-ok":c.ok===false?"v-fail":"v-warn";\n' +
'    var icon=c.ok===true?"&#x2713;":c.ok===false?"&#x2297;":"&#x26a0;";\n' +
'    return "<div class=\\"v-row "+cls+"\\"><span>"+icon+"</span><span>"+c.msg+"</span></div>";\n' +
'  }).join("");\n' +
'}\n' +
'\n' +
'function renderEndpointHistory() {\n' +
'  var list=document.getElementById("histList");\n' +
'  var cnt=document.getElementById("epHistCount");\n' +
'  if(!list){return;}\n' +
'  if(cnt){cnt.textContent=epHistory.length?"("+epHistory.length+")":"";}\n' +
'  if(!epHistory.length){\n' +
'    list.innerHTML="<div class=\\"empty-state\\" style=\\"padding:10px 0\\"><span class=\\"empty-label\\">Realiza una peticion para ver el historial</span></div>";\n' +
'    return;\n' +
'  }\n' +
'  var html="";\n' +
'  for(var i=epHistory.length-1;i>=0;i--){\n' +
'    var h=epHistory[i];\n' +
'    var cls=h.status>=500?"s5":h.status>=400?"s4":h.status>=300?"s3":h.status>0?"s2":"se";\n' +
'    var mc=MC[h.method]||"#888";\n' +
'    html+="<div class=\\"hist-item\\" onclick=\\"loadHistEntry("+i+")\\">"+\n' +
'      "<span class=\\"hist-method\\" style=\\"background:"+mc+"22;color:"+mc+";border:1px solid "+mc+"44\\">"+h.method+"</span>"+\n' +
'      "<span class=\\"status-pill "+cls+"\\" style=\\"font-size:10px;padding:0 5px\\">"+(h.status||"ERR")+"</span>"+\n' +
'      "<span class=\\"hist-route\\">"+h.url+"</span>"+\n' +
'      "<span class=\\"hist-time\\">"+h.elapsed+"ms</span>"+\n' +
'      "<span class=\\"hist-time\\">"+h.time+"</span></div>";\n' +
'  }\n' +
'  list.innerHTML=html;\n' +
'}\n' +
'function loadHistEntry(idx) {\n' +
'  var h=epHistory[idx]; if(h){showRes(h.status,h.statusText,h.headers,h.body,h.elapsed,h.method);}\n' +
'}\n' +
'function clearEndpointHistory() {\n' +
'  epHistory=[];\n' +
'  renderEndpointHistory();\n' +
'  vscode.postMessage({command:"clearEndpointHistory"});\n' +
'  toast("Historial del endpoint limpiado");\n' +
'}\n' +
'\n' +
'function renderGlobalHistory() {\n' +
'  var list=document.getElementById("globalList");\n' +
'  var cnt=document.getElementById("globalCount");\n' +
'  var se=document.getElementById("globalSearch"); var search=se?se.value.toLowerCase():"";\n' +
'  var fe=document.getElementById("globalFilter"); var filter=fe?fe.value:"";\n' +
'  if(!list){return;}\n' +
'  var items=globalHistory.slice().reverse();\n' +
'  if(filter){items=items.filter(function(h){return h.method===filter;});}\n' +
'  if(search){items=items.filter(function(h){\n' +
'    return (h.url||"").toLowerCase().indexOf(search)!==-1||\n' +
'           (h.functionName||"").toLowerCase().indexOf(search)!==-1||\n' +
'           (h.fileName||"").toLowerCase().indexOf(search)!==-1||\n' +
'           String(h.status).indexOf(search)!==-1;\n' +
'  });}\n' +
'  if(cnt){cnt.textContent=items.length+" request"+(items.length!==1?"s":"");}\n' +
'  if(!items.length){\n' +
'    var msg=globalHistory.length?"Sin resultados para el filtro":"Aun no hay requests en el historial global";\n' +
'    list.innerHTML="<div class=\\"global-empty\\"><span>"+msg+"</span></div>";\n' +
'    return;\n' +
'  }\n' +
'  window._globalRendered=items;\n' +
'  var html="";\n' +
'  for(var i=0;i<items.length;i++){\n' +
'    var h=items[i];\n' +
'    var cls=h.status>=500?"s5":h.status>=400?"s4":h.status>=300?"s3":h.status>0?"s2":"se";\n' +
'    var mc=MC[h.method]||"#888";\n' +
'    html+="<div class=\\"hist-item\\" onclick=\\"loadGlobalEntry("+i+")\\">"+\n' +
'      "<span class=\\"hist-method\\" style=\\"background:"+mc+"22;color:"+mc+";border:1px solid "+mc+"44\\">"+h.method+"</span>"+\n' +
'      "<span class=\\"status-pill "+cls+"\\" style=\\"font-size:10px;padding:0 5px\\">"+(h.status||"ERR")+"</span>"+\n' +
'      (h.functionName?"<span class=\\"hist-fn\\" title=\\""+h.functionName+"\\">"+h.functionName+"</span>":"")+\n' +
'      "<span class=\\"hist-route\\" title=\\""+h.url+"\\">"+h.url+"</span>"+\n' +
'      "<span class=\\"hist-time\\">"+h.elapsed+"ms</span>"+\n' +
'      "<span class=\\"hist-time\\">"+h.time+"</span></div>";\n' +
'  }\n' +
'  list.innerHTML=html;\n' +
'}\n' +
'function loadGlobalEntry(idx) {\n' +
'  var items=window._globalRendered||[]; var h=items[idx]; if(!h){return;}\n' +
'  switchTab("test", document.querySelector(".tab-btn[onclick*=\'test\']"));\n' +
'  showRes(h.status,h.statusText,h.headers,h.body,h.elapsed,h.method);\n' +
'}\n' +
'function clearGlobalHistory() {\n' +
'  globalHistory=[];\n' +
'  renderGlobalHistory();\n' +
'  vscode.postMessage({command:"clearGlobalHistory"});\n' +
'  toast("Historial global limpiado");\n' +
'}\n' +
'\n' +
'async function runRequest() {\n' +
'  var url=buildUrl(); var btn=document.getElementById("runBtn");\n' +
'  btn.disabled=true; btn.classList.add("loading");\n' +
'  var opts=buildFetchOptions(); var t0=performance.now();\n' +
'  try {\n' +
'    var res=await fetch(url,opts);\n' +
'    var elapsed=Math.round(performance.now()-t0);\n' +
'    var rh={}; res.headers.forEach(function(v,k){rh[k]=v;});\n' +
'    var body=await res.text();\n' +
'    var entry={url:url,method:opts.method,status:res.status,statusText:res.statusText,headers:rh,body:body,elapsed:elapsed,time:new Date().toLocaleTimeString()};\n' +
'    epHistory.push(entry); if(epHistory.length>30){epHistory.shift();}\n' +
'    globalHistory.push(entry); if(globalHistory.length>100){globalHistory.shift();}\n' +
'    vscode.postMessage({command:"saveHistoryEntry",entry:entry});\n' +
'    renderEndpointHistory();\n' +
'    if(activeTab==="global"){renderGlobalHistory();}\n' +
'    showRes(res.status,res.statusText,rh,body,elapsed,opts.method);\n' +
'  } catch(err) {\n' +
'    var elapsed=Math.round(performance.now()-t0);\n' +
'    var entry={url:url,method:opts.method,status:0,statusText:"Error",headers:{},body:err.message,elapsed:elapsed,time:new Date().toLocaleTimeString()};\n' +
'    epHistory.push(entry); globalHistory.push(entry);\n' +
'    vscode.postMessage({command:"saveHistoryEntry",entry:entry});\n' +
'    renderEndpointHistory();\n' +
'    if(activeTab==="global"){renderGlobalHistory();}\n' +
'    document.getElementById("responseContainer").innerHTML=\n' +
'      "<div class=\\"response-area\\">"+\n' +
'      "<div class=\\"res-header\\"><span class=\\"status-pill se\\">Error de red</span>"+\n' +
'      "<div class=\\"res-meta\\"><span>"+elapsed+"ms</span></div></div>"+\n' +
'      "<div class=\\"res-body\\">"+\n' +
'      "<div class=\\"v-row v-fail\\"><span>&#x2297;</span><div><strong>No se pudo conectar</strong>"+\n' +
'      "<div style=\\"font-size:11px;opacity:.8\\">"+err.message+"</div></div></div>"+\n' +
'      "<div class=\\"v-row v-warn\\" style=\\"margin-top:6px\\"><span>&#x26a0;</span>"+\n' +
'      "<span>Servidor en <code>"+getBase()+"</code> no responde</span></div>"+\n' +
'      "</div></div>";\n' +
'  }\n' +
'  btn.disabled=false; btn.classList.remove("loading");\n' +
'}\n' +
'\n' +
'function showRes(status,statusText,resHeaders,body,elapsed,method) {\n' +
'  var cls=status>=500?"s5":status>=400?"s4":status>=300?"s3":"s2";\n' +
'  var fb=""; var isJson=false;\n' +
'  try{fb=hlJson(JSON.stringify(JSON.parse(body),null,2));isJson=true;}\n' +
'  catch(e){fb=body.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;");}\n' +
'  var hHtml=""; var rh=resHeaders||{};\n' +
'  Object.keys(rh).forEach(function(k){\n' +
'    hHtml+="<tr><td>"+k+"</td><td>"+String(rh[k]).replace(/</g,"&lt;")+"</td></tr>";\n' +
'  });\n' +
'  var vHtml=renderValidation(validate(status,body,elapsed,method||getCurrentMethod()));\n' +
'  var len=body.length>1024?(body.length/1024).toFixed(1)+" KB":body.length+" B";\n' +
'  var hc=Object.keys(rh).length;\n' +
'  document.getElementById("responseContainer").innerHTML=\n' +
'    "<div class=\\"response-area\\">"+\n' +
'    "<div class=\\"res-header\\"><span class=\\"status-pill "+cls+"\\">"+status+" "+statusText+"</span>"+\n' +
'    "<div class=\\"res-meta\\"><span>"+elapsed+"ms</span><span>"+len+"</span></div></div>"+\n' +
'    "<div class=\\"res-tabs\\">"+\n' +
'    "<button class=\\"res-tab-btn active\\" onclick=\\"switchRes(\'rb\',this)\\">Body"+(isJson?" (JSON)":"")+"</button>"+\n' +
'    "<button class=\\"res-tab-btn\\" onclick=\\"switchRes(\'rh\',this)\\">Headers ("+hc+")</button>"+\n' +
'    "<button class=\\"res-tab-btn\\" onclick=\\"switchRes(\'rv\',this)\\">Validacion</button>"+\n' +
'    "</div>"+\n' +
'    "<div id=\\"rb\\" class=\\"res-body\\">"+(fb||"<span style=\\"font-style:italic\\">Sin body</span>")+"</div>"+\n' +
'    "<div id=\\"rh\\" class=\\"res-body\\" style=\\"display:none;padding:6px 0\\"><table class=\\"res-headers-table\\">"+hHtml+"</table></div>"+\n' +
'    "<div id=\\"rv\\" class=\\"res-body\\" style=\\"display:none;padding:10px 12px\\">"+vHtml+"</div>"+\n' +
'    "</div>";\n' +
'}\n' +
'function switchRes(tab,btn) {\n' +
'  ["rb","rh","rv"].forEach(function(t){\n' +
'    var el=document.getElementById(t); if(el){el.style.display=t===tab?"block":"none";}\n' +
'  });\n' +
'  document.querySelectorAll(".res-tab-btn").forEach(function(b){b.classList.remove("active");});\n' +
'  btn.classList.add("active");\n' +
'}\n';
}

export function buildPreviewHtml(
  webview: vscode.Webview,
  ep: Endpoint,
  serverConfig: ServerConfig | undefined,
  gifUri: vscode.Uri,
  gifUri2: vscode.Uri,
  savedEndpointHistory: any[] = [],
  savedGlobalHistory:   any[] = []
): string {
  const escapedCode = (ep.sourceCode ?? '# No disponible')
    .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');

  const methodBadgeColor: Record<string, string> = {
    GET:'#22c55e', POST:'#3b82f6', PUT:'#eab308', PATCH:'#f97316',
    DELETE:'#ef4444', HEAD:'#a855f7', OPTIONS:'#6b7280',
  };
  const badgeColor = methodBadgeColor[ep.method] ?? '#888';

  const hasErrors   = ep.issues?.some(i => i.type === 'error') || ep.isDuplicate;
  const hasWarnings = ep.issues?.some(i => i.type === 'warning');

  let issuesHtml = '';
  if (ep.isDuplicate) {
    issuesHtml += `<div class="issue-banner issue-error"><span class="issue-icon">&#x2297;</span><div><strong>Endpoint duplicado</strong><span>Colisiona con: <code>${ep.duplicateOf ?? 'desconocido'}</code></span></div></div>`;
  }
  if (ep.issues) {
    for (const issue of ep.issues) {
      issuesHtml += `<div class="issue-banner issue-${issue.type}"><span class="issue-icon">${issue.type === 'error' ? '&#x2297;' : '&#x26a0;'}</span><div><span>${issue.message}</span></div></div>`;
    }
  }

  const detectedUrl     = serverConfig?.baseUrl ?? 'http://localhost:5000';
  const confidenceLabel = serverConfig
    ? ({ high: 'detectado', medium: 'inferido', low: 'default' })[serverConfig.confidence]
    : 'default';
  const confidenceColor = serverConfig
    ? ({ high: '#22c55e', medium: '#eab308', low: '#888' })[serverConfig.confidence]
    : '#888';
  const sourceLabel = serverConfig?.source ?? 'fallback';

  const routeParams = [
    ...ep.route.matchAll(/<(?:\w+:)?(\w+)>/g),
    ...ep.route.matchAll(/\{(\w+)\}/g),
  ].map(m => m[1]);

  const paramsInputsHtml = routeParams.map(p =>
    `<div class="param-row"><label class="param-label">${p}</label>` +
    `<input class="param-input" id="param-${p}" type="text" placeholder="valor" oninput="updateUrlPreview()"/></div>`
  ).join('');

  const candidateUrls        = buildCandidateUrls(serverConfig);
  const candidateOptionsHtml = candidateUrls
    .map(u => `<option value="${u}"${u === detectedUrl ? ' selected' : ''}>${u}</option>`)
    .join('');

  const methodsWithBody  = ['POST', 'PUT', 'PATCH'];
  const hasBodyByDefault = methodsWithBody.includes(ep.method.toUpperCase());

  function inferBodyTemplate(): string {
    if (!hasBodyByDefault) { return ''; }
    const route = ep.route.toLowerCase();
    const fn    = ep.functionName.toLowerCase();
    const name  = fn
      .replace(/^(create|add|post|register|new|update|edit|put|patch|set|save|submit|send|upload|login|signup|authenticate|auth)_?/i, '')
      .replace(/_?(create|update|edit|save|submit|send|upload)$/i, '')
      .trim();
    if (/login|signin|authenticate|auth/.test(fn) || /login|signin|auth/.test(route)) {
      return JSON.stringify({ username: '', password: '' }, null, 2);
    }
    if (/register|signup/.test(fn) || /register|signup/.test(route)) {
      return JSON.stringify({ username: '', email: '', password: '' }, null, 2);
    }
    if (/upload|file/.test(fn) || /upload|file/.test(route)) {
      return JSON.stringify({ filename: '', content: '' }, null, 2);
    }
    if (name && name.length > 2) {
      const base: Record<string, string | number> = {};
      base[`${name}_name`] = '';
      if (/email/.test(fn + route))             { base['email']       = ''; }
      if (/price|cost|amount/.test(fn + route)) { base['price']       = 0; }
      if (/count|quantity|qty/.test(fn + route)){ base['quantity']    = 1; }
      if (/status|state/.test(fn + route))      { base['status']      = 'active'; }
      if (/desc|description/.test(fn + route))  { base['description'] = ''; }
      return JSON.stringify(base, null, 2);
    }
    return JSON.stringify({ key: 'value' }, null, 2);
  }

  const bodyTemplate    = inferBodyTemplate();
  const escapedBodyTpl  = bodyTemplate.replace(/</g, '&lt;').replace(/>/g, '&gt;');
  const complexityBadge = COMPLEXITY_ICON[ep.complexity ?? 'simple'] ?? '';

  const curlBody    = hasBodyByDefault
    ? ` \\\n  -H "Content-Type: application/json" \\\n  -d '${bodyTemplate.replace(/\n/g, '').replace(/  /g, ' ')}'`
    : '';
  const escapedCurl = (`curl -X ${ep.method} "${detectedUrl}${ep.route}"${curlBody}`)
    .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');

  const epHistJson     = JSON.stringify(savedEndpointHistory);
  const globalHistJson = JSON.stringify(savedGlobalHistory);

  const clientScript = buildClientScript(
    ep, detectedUrl, routeParams, hasBodyByDefault,
    epHistJson, globalHistJson, badgeColor
  );

  return `<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1.0">
<style>
:root{--radius:8px;--gap:14px;}
*{box-sizing:border-box;}
body{font-family:var(--vscode-font-family,'Segoe UI',sans-serif);font-size:13px;color:var(--vscode-foreground);background:var(--vscode-editor-background);margin:0;padding:20px;line-height:1.5;}
.header{display:flex;align-items:center;gap:10px;margin-bottom:16px;}
.method-badge{background:${badgeColor}22;color:${badgeColor};border:1px solid ${badgeColor}55;border-radius:4px;padding:2px 10px;font-weight:700;font-size:11px;letter-spacing:1px;text-transform:uppercase;font-family:monospace;}
.fn-name{font-size:17px;font-weight:600;}
.status-dot{width:8px;height:8px;border-radius:50%;margin-left:auto;background:${hasErrors?'#ef4444':hasWarnings?'#eab308':'#22c55e'};box-shadow:0 0 6px ${hasErrors?'#ef444488':hasWarnings?'#eab30888':'#22c55e88'};flex-shrink:0;}
.issues-section{margin-bottom:12px;display:flex;flex-direction:column;gap:6px;}
.issue-banner{display:flex;align-items:flex-start;gap:10px;padding:8px 12px;border-radius:var(--radius);border-left:3px solid;font-size:12px;}
.issue-error{background:rgba(239,68,68,.08);border-color:#ef4444;color:var(--vscode-errorForeground,#ef4444);}
.issue-warning{background:rgba(234,179,8,.08);border-color:#eab308;color:#eab308;}
.issue-icon{font-size:13px;flex-shrink:0;margin-top:1px;}
.issue-banner div{display:flex;flex-direction:column;gap:2px;}
.issue-banner strong{font-weight:600;}
.issue-banner code{font-family:monospace;font-size:11px;background:rgba(128,128,128,.15);padding:1px 4px;border-radius:3px;}
.meta-grid{display:grid;grid-template-columns:auto 1fr;gap:5px 14px;margin-bottom:var(--gap);padding:10px 14px;background:var(--vscode-editorWidget-background,rgba(128,128,128,.08));border-radius:var(--radius);border:1px solid var(--vscode-widget-border,rgba(128,128,128,.2));}
.meta-label{color:var(--vscode-descriptionForeground);font-size:10px;text-transform:uppercase;letter-spacing:.5px;align-self:center;white-space:nowrap;}
.meta-value{font-family:monospace;font-size:12px;}
.complexity-simple{color:#22c55e}.complexity-medium{color:#eab308}.complexity-complex{color:#ef4444}
.tab-row{display:flex;align-items:center;justify-content:space-between;margin-bottom:8px;border-bottom:1px solid var(--vscode-widget-border,rgba(128,128,128,.2));padding-bottom:6px;}
.tabs{display:flex;gap:2px;}
.tab-btn{background:none;border:none;border-bottom:2px solid transparent;padding:4px 12px;font-size:12px;color:var(--vscode-descriptionForeground);cursor:pointer;font-family:var(--vscode-font-family,sans-serif);transition:all .12s;margin-bottom:-7px;}
.tab-btn.active{color:var(--vscode-foreground);border-bottom-color:${badgeColor};}
.tab-content{display:none;}
.tab-content.active{display:block;}
.copy-btn{display:flex;align-items:center;gap:5px;background:var(--vscode-button-secondaryBackground,rgba(128,128,128,.15));color:var(--vscode-button-secondaryForeground,var(--vscode-foreground));border:1px solid var(--vscode-widget-border,rgba(128,128,128,.2));border-radius:4px;padding:3px 10px;font-size:11px;cursor:pointer;transition:all .15s;font-family:var(--vscode-font-family,sans-serif);}
.copy-btn.copied{color:#22c55e;border-color:#22c55e44;background:#22c55e11;}
pre{background:var(--vscode-textCodeBlock-background,rgba(128,128,128,.1));border:1px solid var(--vscode-widget-border,rgba(128,128,128,.2));border-radius:var(--radius);padding:14px;overflow-x:auto;font-family:var(--vscode-editor-font-family,monospace);font-size:12px;line-height:1.6;margin:0;}
.postman-section{display:flex;flex-direction:column;gap:10px;}
.server-banner{display:flex;align-items:center;gap:8px;padding:7px 12px;border-radius:6px;font-size:11px;background:rgba(128,128,128,.06);border:1px solid var(--vscode-widget-border,rgba(128,128,128,.2));}
.server-dot{width:7px;height:7px;border-radius:50%;flex-shrink:0;background:#888;transition:all .3s;}
.server-dot.live{background:#22c55e;box-shadow:0 0 5px #22c55e88;}
.server-dot.dead{background:#ef4444;box-shadow:0 0 5px #ef444488;}
.server-dot.checking{background:#eab308;animation:pulse 1s infinite;}
@keyframes pulse{0%,100%{opacity:1}50%{opacity:.4}}
.server-label{flex:1;color:var(--vscode-descriptionForeground);}
.server-label strong{color:var(--vscode-foreground);font-family:monospace;}
.server-confidence{font-size:10px;padding:1px 6px;border-radius:10px;color:${confidenceColor};border:1px solid ${confidenceColor}44;background:${confidenceColor}11;font-weight:600;}
.ping-btn{background:none;border:1px solid var(--vscode-widget-border,rgba(128,128,128,.2));color:var(--vscode-descriptionForeground);border-radius:4px;padding:1px 8px;font-size:10px;cursor:pointer;font-family:var(--vscode-font-family,sans-serif);}
.url-bar{display:flex;align-items:center;gap:6px;background:var(--vscode-input-background,rgba(128,128,128,.1));border:1px solid var(--vscode-input-border,rgba(128,128,128,.3));border-radius:var(--radius);padding:4px 8px;}
.method-select{background:var(--vscode-dropdown-background,rgba(0,0,0,.2));color:var(--vscode-foreground);border:1px solid var(--vscode-widget-border,rgba(128,128,128,.35));border-radius:4px;font-size:11px;font-weight:700;font-family:monospace;padding:2px 6px;cursor:pointer;outline:none;flex-shrink:0;}
.method-select option{background:var(--vscode-dropdown-background,#1e1e2e);color:var(--vscode-foreground);}
.url-select{background:none;border:none;color:var(--vscode-descriptionForeground);font-size:11px;font-family:monospace;outline:none;cursor:pointer;border-right:1px solid var(--vscode-widget-border,rgba(128,128,128,.25));padding-right:6px;margin-right:2px;max-width:185px;}
.url-select option{background:var(--vscode-dropdown-background,#1e1e2e);color:var(--vscode-foreground);}
.url-route-editable{flex:1;background:none;border:none;outline:none;font-size:12px;font-family:monospace;color:var(--vscode-foreground);min-width:0;}
.run-btn{flex-shrink:0;display:flex;align-items:center;gap:5px;background:${badgeColor}22;color:${badgeColor};border:1px solid ${badgeColor}55;border-radius:4px;padding:5px 16px;font-size:12px;font-weight:700;cursor:pointer;transition:all .15s;white-space:nowrap;font-family:var(--vscode-font-family,sans-serif);}
.run-btn:hover:not(:disabled){background:${badgeColor}33;border-color:${badgeColor}99;}
.run-btn:disabled{opacity:.4;cursor:not-allowed;}
.run-btn .spinner{display:none;width:10px;height:10px;border:2px solid ${badgeColor}44;border-top-color:${badgeColor};border-radius:50%;animation:spin .6s linear infinite;}
.run-btn.loading .btn-label{display:none;}
.run-btn.loading .spinner{display:block;}
@keyframes spin{to{transform:rotate(360deg)}}
.url-preview{font-size:10px;font-family:monospace;color:var(--vscode-descriptionForeground);padding:3px 10px;background:rgba(128,128,128,.04);border-radius:4px;border:1px solid transparent;word-break:break-all;}
.url-preview.has-params{color:var(--vscode-foreground);border-color:${badgeColor}22;}
.params-box{background:var(--vscode-editorWidget-background,rgba(128,128,128,.05));border:1px solid var(--vscode-widget-border,rgba(128,128,128,.18));border-radius:var(--radius);padding:8px 12px;}
.params-title{font-size:10px;text-transform:uppercase;letter-spacing:.5px;color:var(--vscode-descriptionForeground);margin-bottom:6px;font-weight:600;}
.param-row{display:flex;align-items:center;gap:8px;margin-bottom:5px;}
.param-label{font-size:11px;font-family:monospace;color:${badgeColor};min-width:80px;white-space:nowrap;}
.param-input,.query-input,.header-input{flex:1;background:var(--vscode-input-background,rgba(128,128,128,.1));color:var(--vscode-input-foreground,var(--vscode-foreground));border:1px solid var(--vscode-input-border,rgba(128,128,128,.25));border-radius:4px;padding:3px 8px;font-size:12px;font-family:monospace;outline:none;}
.query-row,.header-row{display:flex;align-items:center;gap:6px;margin-bottom:5px;}
.sep{color:var(--vscode-descriptionForeground);font-size:12px;flex-shrink:0;}
.icon-btn{background:none;border:1px solid var(--vscode-widget-border,rgba(128,128,128,.2));color:var(--vscode-descriptionForeground);border-radius:4px;width:20px;height:20px;cursor:pointer;font-size:13px;display:flex;align-items:center;justify-content:center;flex-shrink:0;}
.add-row-btn{background:none;border:1px dashed var(--vscode-widget-border,rgba(128,128,128,.3));color:var(--vscode-descriptionForeground);border-radius:4px;padding:2px 10px;font-size:11px;cursor:pointer;margin-top:6px;display:inline-flex;align-items:center;gap:4px;font-family:var(--vscode-font-family,sans-serif);}
.body-editor-wrap{display:flex;flex-direction:column;gap:6px;}
.body-format-row{display:flex;align-items:center;gap:8px;}
.body-format-select{background:var(--vscode-dropdown-background,rgba(0,0,0,.2));color:var(--vscode-foreground);border:1px solid var(--vscode-widget-border,rgba(128,128,128,.25));border-radius:4px;font-size:11px;padding:2px 6px;outline:none;cursor:pointer;font-family:var(--vscode-font-family,sans-serif);}
.body-actions{display:flex;gap:6px;align-items:center;}
.body-action-btn{background:none;border:1px solid var(--vscode-widget-border,rgba(128,128,128,.2));color:var(--vscode-descriptionForeground);border-radius:4px;padding:2px 8px;font-size:10px;cursor:pointer;font-family:var(--vscode-font-family,sans-serif);}
.body-validation{font-size:10px;padding:2px 8px;border-radius:3px;display:none;}
.body-valid{background:#22c55e11;color:#22c55e;border:1px solid #22c55e33;display:inline-block;}
.body-invalid{background:#ef444411;color:#ef4444;border:1px solid #ef444433;display:inline-block;}
.editor-outer{border-radius:var(--radius);overflow:hidden;border:1px solid rgba(128,128,128,.18);background:#0d1117;transition:border-color .15s;}
.editor-outer:focus-within{border-color:${badgeColor}55;box-shadow:0 0 0 2px ${badgeColor}18;}
.editor-topbar{display:flex;align-items:center;justify-content:space-between;padding:5px 10px;background:#161b22;border-bottom:1px solid rgba(128,128,128,.12);}
.editor-topbar-lang{font-size:9px;font-weight:600;letter-spacing:.8px;text-transform:uppercase;color:rgba(255,255,255,.25);font-family:monospace;}
.editor-topbar-actions{display:flex;gap:4px;}
.editor-topbar-btn{background:none;border:1px solid rgba(255,255,255,.1);color:rgba(255,255,255,.4);border-radius:3px;padding:1px 7px;font-size:9px;cursor:pointer;font-family:var(--vscode-font-family,sans-serif);transition:all .12s;letter-spacing:.3px;}
.editor-topbar-btn:hover{border-color:${badgeColor}66;color:${badgeColor};}
.editor-wrap{display:flex;background:#0d1117;font-family:'Cascadia Code','Fira Code','JetBrains Mono',var(--vscode-editor-font-family,monospace);font-size:12.5px;line-height:1.75;}
.editor-gutter{width:40px;flex-shrink:0;background:#0d1117;border-right:1px solid rgba(255,255,255,.05);padding:10px 0;text-align:right;user-select:none;counter-reset:ln;}
.editor-gutter span{display:block;padding-right:8px;font-size:11px;color:rgba(255,255,255,.2);line-height:1.75;font-variant-numeric:tabular-nums;}
.editor-gutter span.active-ln{color:rgba(255,255,255,.7);}
.editor-scroll{flex:1;overflow:auto;position:relative;}
.editor-input{display:block;width:100%;padding:10px 12px;background:transparent;border:none;outline:none;resize:none;font-family:inherit;font-size:inherit;line-height:inherit;color:#e6edf3;caret-color:#58a6ff;tab-size:2;white-space:pre;overflow-wrap:normal;overflow-x:auto;min-height:120px;height:auto;}
.collapse-toggle{background:none;border:none;cursor:pointer;width:100%;display:flex;align-items:center;gap:6px;padding:5px 0;color:var(--vscode-descriptionForeground);font-size:10px;text-transform:uppercase;letter-spacing:.5px;font-weight:600;font-family:var(--vscode-font-family,sans-serif);}
.c-arrow{transition:transform .15s;font-size:8px;}
.c-arrow.open{transform:rotate(90deg);}
.collapsible{overflow:hidden;transition:max-height .2s ease;}
.collapsible.closed{max-height:0!important;}
.response-area{border-radius:var(--radius);overflow:hidden;border:1px solid var(--vscode-widget-border,rgba(128,128,128,.2));animation:fadeIn .2s ease;}
@keyframes fadeIn{from{opacity:0;transform:translateY(3px)}to{opacity:1}}
.res-header{display:flex;align-items:center;gap:8px;padding:7px 12px;background:var(--vscode-editorWidget-background,rgba(128,128,128,.08));border-bottom:1px solid var(--vscode-widget-border,rgba(128,128,128,.15));}
.status-pill{font-size:11px;font-weight:700;font-family:monospace;padding:1px 8px;border-radius:20px;}
.s2{background:#22c55e22;color:#22c55e;border:1px solid #22c55e44}
.s3{background:#3b82f622;color:#3b82f6;border:1px solid #3b82f644}
.s4{background:#f9731622;color:#f97316;border:1px solid #f9731644}
.s5{background:#ef444422;color:#ef4444;border:1px solid #ef444444}
.se{background:#88888822;color:#888;border:1px solid #88888844}
.res-meta{font-size:11px;color:var(--vscode-descriptionForeground);margin-left:auto;display:flex;gap:10px;}
.res-tabs{display:flex;border-bottom:1px solid var(--vscode-widget-border,rgba(128,128,128,.15));}
.res-tab-btn{background:none;border:none;border-bottom:2px solid transparent;padding:4px 12px;font-size:11px;cursor:pointer;color:var(--vscode-descriptionForeground);font-family:var(--vscode-font-family,sans-serif);}
.res-tab-btn.active{color:var(--vscode-foreground);border-bottom-color:${badgeColor};}
.res-body{padding:10px 12px;max-height:300px;overflow-y:auto;font-family:monospace;font-size:12px;line-height:1.6;white-space:pre-wrap;word-break:break-word;}
.res-headers-table{width:100%;border-collapse:collapse;font-size:11px;}
.res-headers-table tr:nth-child(even){background:rgba(128,128,128,.04);}
.res-headers-table td{padding:3px 8px;vertical-align:top;}
.res-headers-table td:first-child{font-family:monospace;color:${badgeColor};white-space:nowrap;width:1%;padding-right:16px;}
.v-row{padding:5px 8px;border-radius:5px;font-size:12px;display:flex;align-items:flex-start;gap:8px;margin-bottom:5px;}
.v-ok{background:#22c55e11;border:1px solid #22c55e33;color:#22c55e}
.v-warn{background:#eab30811;border:1px solid #eab30833;color:#eab308}
.v-fail{background:#ef444411;border:1px solid #ef444433;color:#ef4444}
.hist-item{display:flex;align-items:center;gap:8px;padding:6px 8px;border-radius:5px;cursor:pointer;font-size:11px;border:1px solid transparent;}
.hist-item:hover{background:rgba(128,128,128,.08);border-color:var(--vscode-widget-border,rgba(128,128,128,.2));}
.hist-method{font-size:9px;font-weight:700;font-family:monospace;padding:1px 5px;border-radius:3px;flex-shrink:0;}
.hist-fn{font-size:10px;color:var(--vscode-descriptionForeground);flex-shrink:0;max-width:90px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;}
.hist-route{font-family:monospace;flex:1;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;}
.hist-time{color:var(--vscode-descriptionForeground);flex-shrink:0;font-size:10px;}
.chips{display:flex;flex-wrap:wrap;gap:5px;}
.chip{font-size:10px;padding:2px 8px;border-radius:20px;cursor:pointer;border:1px solid var(--vscode-widget-border,rgba(128,128,128,.25));color:var(--vscode-descriptionForeground);background:none;font-family:var(--vscode-font-family,sans-serif);}
.chip:hover{border-color:${badgeColor}66;color:${badgeColor};background:${badgeColor}11;}
.empty-state{display:flex;flex-direction:column;align-items:center;justify-content:center;gap:8px;padding:26px 0;color:var(--vscode-descriptionForeground);}
.empty-label{font-size:11px;opacity:.65;text-align:center;}
#tab-global .global-wrap{display:flex;flex-direction:column;gap:12px;}
#tab-global .global-toolbar{display:flex;align-items:center;justify-content:space-between;padding:6px 0;}
#tab-global .global-toolbar-left{display:flex;align-items:center;gap:8px;}
#tab-global .global-count{font-size:11px;color:var(--vscode-descriptionForeground);}
#tab-global .global-search{background:var(--vscode-input-background,rgba(128,128,128,.1));color:var(--vscode-foreground);border:1px solid var(--vscode-input-border,rgba(128,128,128,.25));border-radius:4px;padding:3px 8px;font-size:11px;font-family:monospace;outline:none;width:160px;}
#tab-global .global-filter{background:var(--vscode-dropdown-background,rgba(0,0,0,.2));color:var(--vscode-foreground);border:1px solid var(--vscode-widget-border,rgba(128,128,128,.25));border-radius:4px;font-size:11px;padding:2px 6px;outline:none;cursor:pointer;font-family:var(--vscode-font-family,sans-serif);}
#tab-global .clear-global-btn{background:none;border:1px solid rgba(239,68,68,.35);color:#ef4444;border-radius:4px;padding:2px 10px;font-size:10px;cursor:pointer;font-family:var(--vscode-font-family,sans-serif);}
#tab-global .global-list{display:flex;flex-direction:column;gap:4px;max-height:420px;overflow-y:auto;}
#tab-global .global-empty{display:flex;flex-direction:column;align-items:center;gap:8px;padding:40px 0;color:var(--vscode-descriptionForeground);opacity:.6;font-size:12px;}
.jk{color:#7dd3fc}.js{color:#86efac}.jn{color:#fda4af}.jb{color:#d8b4fe}.jnull{color:#94a3b8}
#toast{position:fixed;bottom:14px;right:14px;background:#22c55e22;color:#22c55e;border:1px solid #22c55e44;border-radius:6px;padding:5px 12px;font-size:11px;z-index:999;display:none;}
</style>
</head>
<body>

<div id="loadOverlay" style="position:fixed;inset:0;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:16px;background:var(--vscode-editor-background);z-index:9999;transition:opacity .35s ease;">
  <svg xmlns="http://www.w3.org/2000/svg" width="48" height="48" viewBox="0 0 24 24">
    <defs><mask id="lm">
      <path fill="none" stroke="#fff" stroke-dasharray="60" stroke-linecap="round" stroke-width="2" d="M12 3c4.97 0 9 4.03 9 9s-4.03 9-9 9-9-4.03-9-9 4.03-9 9-9Z"><animate fill="freeze" attributeName="stroke-dashoffset" dur=".6s" values="60;0"/></path>
      <path fill="#fff" d="M11 11l1 1l1 1l-1-1Z" transform="rotate(-180 12 12)"><animate fill="freeze" attributeName="d" begin=".6s" dur=".15s" to="M10.2 10.2l6.8-3.2l-3.2 6.8l-6.8 3.2Z"/><animateTransform fill="freeze" attributeName="transform" begin=".6s" dur=".5s" type="rotate" values="-180 12 12;0 12 12"/></path>
      <circle cx="12" cy="12"><animate fill="freeze" attributeName="r" begin=".6s" dur=".25s" to="1"/></circle>
    </mask></defs>
    <path fill="${badgeColor}" d="M0 0h24v24H0z" mask="url(#lm)"/>
  </svg>
  <span style="font-size:12px;color:${badgeColor};font-family:var(--vscode-font-family,sans-serif);">${ep.method} · ${ep.functionName}</span>
  <span style="font-size:10px;color:var(--vscode-descriptionForeground);opacity:.5;">${ep.route}</span>
</div>
<script>window.addEventListener("load",function(){var o=document.getElementById("loadOverlay");if(o){setTimeout(function(){o.style.opacity="0";setTimeout(function(){o.remove();},380);},600);}});</script>

<div class="header">
  <span class="method-badge">${ep.method}</span>
  <span class="fn-name">${ep.functionName}</span>
  <span class="status-dot" title="${hasErrors?'Tiene errores':hasWarnings?'Advertencias':'Sin problemas'}"></span>
</div>

${issuesHtml ? `<div class="issues-section">${issuesHtml}</div>` : ''}

<div class="meta-grid">
  <span class="meta-label">Ruta</span>        <span class="meta-value">${ep.route}</span>
  <span class="meta-label">Framework</span>   <span class="meta-value">${ep.framework}</span>
  <span class="meta-label">Archivo</span>     <span class="meta-value">${ep.fileName}</span>
  <span class="meta-label">Lineas</span>      <span class="meta-value">${ep.lineStart} &rarr; ${ep.lineEnd} <span style="color:var(--vscode-descriptionForeground)">(${ep.lineCount} lineas)</span></span>
  <span class="meta-label">Complejidad</span> <span class="meta-value complexity-${ep.complexity ?? 'simple'}">${complexityBadge} ${ep.complexity ?? '&mdash;'}</span>
</div>

<div>
  <div class="tab-row">
    <div class="tabs">
      <button class="tab-btn"        onclick="switchTab('python',this)">Python</button>
      <button class="tab-btn"        onclick="switchTab('curl',this)">cURL</button>
      <button class="tab-btn active" onclick="switchTab('test',this)">&#x25B6; Test</button>
      <button class="tab-btn"        onclick="switchTab('global',this)">&#x1F310; Global</button>
    </div>
    <button class="copy-btn" id="copyBtn" onclick="copyActive()">&#x2358; Copiar</button>
  </div>

  <div id="tab-python" class="tab-content"><pre><code id="code-python">${escapedCode}</code></pre></div>
  <div id="tab-curl"   class="tab-content"><pre><code id="code-curl">${escapedCurl}</code></pre></div>

  <div id="tab-test" class="tab-content active">
  <div class="postman-section">
    <div class="server-banner">
      <div class="server-dot checking" id="serverDot"></div>
      <span class="server-label">Servidor: <strong id="serverUrlLabel">${detectedUrl}</strong>
        <span style="color:var(--vscode-descriptionForeground);font-size:10px;margin-left:4px">desde <em>${sourceLabel}</em></span>
      </span>
      <span class="server-confidence">${confidenceLabel}</span>
      <button class="ping-btn" onclick="pingServer()">&#x21BB; ping</button>
    </div>

    <div class="url-bar">
      <select class="method-select" id="methodSelect" onchange="onMethodChange()">
        <option value="GET"${ep.method==='GET'?' selected':''}>GET</option>
        <option value="POST"${ep.method==='POST'?' selected':''}>POST</option>
        <option value="PUT"${ep.method==='PUT'?' selected':''}>PUT</option>
        <option value="PATCH"${ep.method==='PATCH'?' selected':''}>PATCH</option>
        <option value="DELETE"${ep.method==='DELETE'?' selected':''}>DELETE</option>
        <option value="HEAD"${ep.method==='HEAD'?' selected':''}>HEAD</option>
        <option value="OPTIONS"${ep.method==='OPTIONS'?' selected':''}>OPTIONS</option>
      </select>
      <select class="url-select" id="baseUrlSelect" onchange="onBaseChange()">
        ${candidateOptionsHtml}
        <option value="__custom__"> + otra URL&hellip;</option>
      </select>
      <input class="url-route-editable" id="routeEditable" type="text" value="${ep.route}" spellcheck="false" oninput="updateUrlPreview()"/>
      <button class="run-btn" id="runBtn" onclick="runRequest()">
        <span class="spinner"></span><span class="btn-label">&#x25B6; Enviar</span>
      </button>
    </div>

    <div class="url-preview" id="urlPreview">${detectedUrl}${ep.route}</div>

    ${routeParams.length > 0 ? `<div class="params-box"><div class="params-title">Parametros de ruta</div>${paramsInputsHtml}</div>` : ''}

    <div class="chips">
      <button class="chip" onclick="runRequest()">&#x25B6; Enviar ahora</button>
      <button class="chip" onclick="copyFullUrl()">&#x2358; Copiar URL</button>
      <button class="chip" onclick="copyCurlFull()">&#x2358; Copiar cURL</button>
      <button class="chip" onclick="openBrowser()">&#x2197; Abrir en navegador</button>
    </div>

    <div id="bodySection">
      <div class="body-format-row" style="margin-bottom:6px;">
        <span class="params-title" style="margin:0">Body</span>
        <select class="body-format-select" id="bodyFormat" onchange="onBodyFormatChange()">
          <option value="json" selected>JSON</option>
          <option value="form">Form URL-encoded</option>
          <option value="text">Texto plano</option>
          <option value="none">Sin body</option>
        </select>
        <span id="bodyMethodHint" style="margin-left:4px;font-size:9px;opacity:.5;color:var(--vscode-descriptionForeground)"></span>
        <span id="bodyValidation" class="body-validation" style="margin-left:auto"></span>
      </div>
      <div id="bodyEditorWrap" class="body-editor-wrap">
        <div class="editor-outer">
          <div class="editor-topbar">
            <span class="editor-topbar-lang">json</span>
            <div class="editor-topbar-actions">
              <button class="editor-topbar-btn" onclick="formatBody()">&#x2934; Format</button>
              <button class="editor-topbar-btn" onclick="copyBody()">&#x2398; Copy</button>
              <button class="editor-topbar-btn" onclick="clearBody()">&#x2715; Clear</button>
            </div>
          </div>
          <div class="editor-wrap">
            <div class="editor-gutter" id="bodyGutter"><span class="active-ln">1</span></div>
            <div class="editor-scroll">
              <textarea class="editor-input" id="bodyInput" spellcheck="false"
                autocomplete="off" autocorrect="off" autocapitalize="off"
                oninput="updateGutter();validateBody();updateCurlPreview();"
                onkeydown="handleBodyKeydown(event)"
                onkeyup="updateGutter()"
                onclick="updateGutter()"
>${escapedBodyTpl}</textarea>
            </div>
          </div>
        </div>
      </div>
    </div>

    <div>
      <button class="collapse-toggle" onclick="toggle('qSection',this)">
        <span class="c-arrow open">&#x25B6;</span> Query Params
      </button>
      <div class="collapsible" id="qSection" style="max-height:300px">
        <div class="params-box">
          <div id="qBuilder">
            <div class="query-row">
              <input class="query-input" placeholder="clave" oninput="updateUrlPreview()"/>
              <span class="sep">=</span>
              <input class="query-input" placeholder="valor" oninput="updateUrlPreview()"/>
              <button class="icon-btn" onclick="rmRow(this,'.query-row')">&#x2212;</button>
            </div>
          </div>
          <button class="add-row-btn" onclick="addQRow()">+ Agregar parametro</button>
        </div>
      </div>
    </div>

    <!-- Auth -->
    <div>
      <button class="collapse-toggle" onclick="toggle('authSection',this)">
        <span class="c-arrow">&#x25B6;</span> Auth
        <span id="authBadge" style="margin-left:6px;font-size:9px;padding:1px 6px;border-radius:10px;display:none;background:${badgeColor}22;color:${badgeColor};border:1px solid ${badgeColor}44;font-weight:600;"></span>
      </button>
      <div class="collapsible closed" id="authSection" style="max-height:300px">
        <div class="params-box">
          <div style="display:flex;align-items:center;gap:8px;margin-bottom:10px;">
            <span class="params-title" style="margin:0">Tipo</span>
            <select class="body-format-select" id="authType" onchange="onAuthTypeChange()">
              <option value="none">Sin auth</option>
              <option value="bearer">Bearer Token (JWT)</option>
              <option value="basic">Basic Auth</option>
              <option value="apikey">API Key</option>
              <option value="custom">Header personalizado</option>
            </select>
          </div>
          <div id="authFields"></div>
          <div id="authPreview" style="display:none;margin-top:8px;padding:6px 10px;border-radius:5px;background:rgba(128,128,128,.06);border:1px solid rgba(128,128,128,.15);font-size:10px;font-family:monospace;color:var(--vscode-descriptionForeground);word-break:break-all;"></div>
        </div>
      </div>
    </div>

    <!-- Variables de entorno -->
    <div>
      <button class="collapse-toggle" onclick="toggle('envSection',this)">
        <span class="c-arrow">&#x25B6;</span> Variables <span style="font-size:9px;opacity:.5;margin-left:4px">&#123;&#123;VAR&#125;&#125;</span>
        <span id="envCount" style="margin-left:4px;font-size:9px;opacity:.6"></span>
      </button>
      <div class="collapsible closed" id="envSection" style="max-height:280px">
        <div class="params-box">
          <div style="font-size:10px;color:var(--vscode-descriptionForeground);margin-bottom:8px;line-height:1.5;">
            Define variables y usalas como <code style="font-family:monospace;background:rgba(128,128,128,.15);padding:1px 4px;border-radius:3px;">&#123;&#123;NOMBRE&#125;&#125;</code> en la URL, headers y body.
          </div>
          <div id="envBuilder"></div>
          <button class="add-row-btn" onclick="addEnvRow()">+ Agregar variable</button>
          <div style="margin-top:8px;display:flex;gap:6px;">
            <button class="body-action-btn" onclick="saveEnvVars()">&#x2713; Guardar</button>
            <button class="body-action-btn" onclick="loadEnvTemplate()">Cargar .env ejemplo</button>
          </div>
        </div>
      </div>
    </div>

    <div>
      <button class="collapse-toggle" onclick="toggle('hSection',this)">
        <span class="c-arrow">&#x25B6;</span> Headers
      </button>
      <div class="collapsible closed" id="hSection" style="max-height:300px">
        <div class="params-box">
          <div id="hBuilder">
            <div class="header-row">
              <input class="header-input" value="Content-Type"/>
              <span class="sep">:</span>
              <input class="header-input" value="application/json"/>
              <button class="icon-btn" onclick="rmRow(this,'.header-row')">&#x2212;</button>
            </div>
          </div>
          <button class="add-row-btn" onclick="addHRow()">+ Agregar header</button>
        </div>
      </div>
    </div>

    <div>
      <button class="collapse-toggle" onclick="toggle('histSection',this)">
        <span class="c-arrow">&#x25B6;</span> Historial de este endpoint
        <span id="epHistCount" style="margin-left:4px;font-size:9px;opacity:.6"></span>
      </button>
      <div class="collapsible closed" id="histSection" style="max-height:220px;overflow-y:auto">
        <div class="params-box" style="display:flex;flex-direction:column;gap:4px;">
          <div style="display:flex;justify-content:flex-end;margin-bottom:4px;">
            <button class="body-action-btn" onclick="clearEndpointHistory()">Limpiar historial</button>
          </div>
          <div id="histList"></div>
        </div>
      </div>
    </div>

    <div id="responseContainer">
      <div class="empty-state">
        <span class="empty-icon"><img src="${gifUri}" alt="" width="90"></span>
        <span class="empty-label">Presiona Enviar para probar el endpoint</span>
      </div>
    </div>
  </div>
  </div>

  <div id="tab-global" class="tab-content">
    <div class="global-wrap">
      <div class="global-toolbar">
        <div class="global-toolbar-left">
          <input class="global-search" id="globalSearch" type="text" placeholder="Buscar ruta, funcion..." oninput="renderGlobalHistory()">
          <select class="global-filter" id="globalFilter" onchange="renderGlobalHistory()">
            <option value="">Todos los metodos</option>
            <option value="GET">GET</option>
            <option value="POST">POST</option>
            <option value="PUT">PUT</option>
            <option value="PATCH">PATCH</option>
            <option value="DELETE">DELETE</option>
          </select>
          <span class="global-count" id="globalCount"></span>
        </div>
        <button class="clear-global-btn" onclick="clearGlobalHistory()">Limpiar todo</button>
      </div>
      <div class="global-list" id="globalList"></div>
    </div>
  </div>
</div>

<div id="toast"></div>
<script>${clientScript}</script>
</body>
</html>`;
}