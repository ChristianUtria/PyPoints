import * as path from 'path';
import * as vscode from 'vscode';
import { Endpoint, ServerConfig } from '../types';
import { buildPreviewHtml } from './Previewhtml';

// ─── Claves de almacenamiento ─────────────────────────────────────────────────
// Historial personal: una entrada por endpoint (METHOD:route)
const ENDPOINT_HISTORY_PREFIX = 'pypoints.history.endpoint.';
// Historial global: todos los requests de todos los endpoints
const GLOBAL_HISTORY_KEY      = 'pypoints.history.global';
const MAX_PER_ENDPOINT        = 30;
const MAX_GLOBAL              = 100;

// ─── Estado del panel ─────────────────────────────────────────────────────────
let currentPanel: vscode.WebviewPanel | undefined;
let isDisposing   = false;

// ─── Clave personal por endpoint ─────────────────────────────────────────────
function endpointKey(ep: Endpoint): string {
  // Usa METHOD:route como identificador único del endpoint
  return ENDPOINT_HISTORY_PREFIX + `${ep.method.toUpperCase()}:${ep.route}`;
}

export function showEndpointPreviewPanel(
  ep: Endpoint,
  context: vscode.ExtensionContext,
  serverConfig?: ServerConfig
): void {

  const buildPanel = () => {
    const panel = vscode.window.createWebviewPanel(
      'endpointPreview',
      ep.functionName,
      vscode.ViewColumn.Beside,
      {
        enableScripts: true,
        retainContextWhenHidden: false,
        localResourceRoots: [
          vscode.Uri.file(path.join(context.extensionPath, 'media'))
        ]
      }
    );

    panel.iconPath = vscode.Uri.file(
      path.join(context.extensionPath, 'media', 'logo_preview.svg')
    );

    const gifUri = panel.webview.asWebviewUri(
      vscode.Uri.file(path.join(context.extensionPath, 'media', 'antena.gif'))
    );
    const gifUri2 = panel.webview.asWebviewUri(
      vscode.Uri.file(path.join(context.extensionPath, 'media', 'forma.gif'))
    );

    // ── Cargar historiales ────────────────────────────────────────────────────
    const savedEndpointHistory = context.globalState.get<any[]>(endpointKey(ep), []);
    const savedGlobalHistory   = context.globalState.get<any[]>(GLOBAL_HISTORY_KEY, []);

    panel.webview.html = buildPreviewHtml(
      panel.webview,
      ep,
      serverConfig,
      gifUri,
      gifUri2,
      savedEndpointHistory,
      savedGlobalHistory
    );

    // ── Mensajes desde el webview ─────────────────────────────────────────────
    panel.webview.onDidReceiveMessage(
      msg => {

        // Abrir URL en navegador externo
        if (msg.command === 'openExternal') {
          vscode.env.openExternal(vscode.Uri.parse(msg.url));
        }

        // Guardar request en historial personal del endpoint Y en el global
        if (msg.command === 'saveHistoryEntry') {
          const entry = { ...msg.entry, functionName: ep.functionName, fileName: ep.fileName };

          // Personal
          const personal = context.globalState.get<any[]>(endpointKey(ep), []);
          personal.push(entry);
          if (personal.length > MAX_PER_ENDPOINT) { personal.shift(); }
          context.globalState.update(endpointKey(ep), personal);

          // Global
          const global = context.globalState.get<any[]>(GLOBAL_HISTORY_KEY, []);
          global.push(entry);
          if (global.length > MAX_GLOBAL) { global.shift(); }
          context.globalState.update(GLOBAL_HISTORY_KEY, global);
        }

        // Limpiar historial personal de este endpoint
        if (msg.command === 'clearEndpointHistory') {
          context.globalState.update(endpointKey(ep), []);
        }

        // Limpiar historial global completo
        if (msg.command === 'clearGlobalHistory') {
          context.globalState.update(GLOBAL_HISTORY_KEY, []);
        }
      },
      undefined,
      context.subscriptions
    );

    panel.onDidDispose(() => {
      isDisposing  = false;
      currentPanel = undefined;
    }, null, context.subscriptions);

    currentPanel = panel;
    isDisposing  = false;
  };

  if (currentPanel && !isDisposing) {
    isDisposing = true;
    currentPanel.dispose();
    setTimeout(buildPanel, 150);
  } else if (!isDisposing) {
    buildPanel();
  } else {
    setTimeout(() => {
      isDisposing = false;
      buildPanel();
    }, 200);
  }
}